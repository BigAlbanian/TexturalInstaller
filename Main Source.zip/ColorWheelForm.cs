﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace Textural
{
    public partial class ColorWheelForm : Form
    {
        private Bitmap colorWheel;
        private Point selectedPoint = new Point(180, 180);
        private float brightness = 1.0f;
        private bool updatingFromWheel = false;
        private bool useOKLAB = false;
        public Color SelectedColor { get; private set; }

        public ColorWheelForm(Color initialColor)
        {
            InitializeComponent();

            SelectedColor = initialColor;
            GenerateColorWheel();

            pictureWheel.Image = colorWheel;
            pictureWheel.MouseDown += PictureWheel_MouseDown;
            pictureWheel.MouseMove += PictureWheel_MouseMove;
            pictureWheel.Paint += PictureWheel_Paint;

            trackBrightness.Scroll += (s, e) =>
            {
                brightness = trackBrightness.Value / 100f;
                UpdatePreview();
            };

            // Wire up RGB inputs
            numR.ValueChanged += NumRGB_ValueChanged;
            numG.ValueChanged += NumRGB_ValueChanged;
            numB.ValueChanged += NumRGB_ValueChanged;

            // Wire up hex input
            txtHex.TextChanged += TxtHex_TextChanged;

            // Wire up OKLAB toggle
            chkOKLAB.CheckedChanged += ChkOKLAB_CheckedChanged;

            btnOK.Click += (s, e) => this.DialogResult = DialogResult.OK;
            btnCancel.Click += (s, e) => this.DialogResult = DialogResult.Cancel;

            SetInitialPosition(initialColor);
            UpdatePreview();
        }

        private void ChkOKLAB_CheckedChanged(object sender, EventArgs e)
        {
            useOKLAB = chkOKLAB.Checked;
            GenerateColorWheel();
            pictureWheel.Image = colorWheel;
            pictureWheel.Invalidate();
        }

        private void TxtHex_TextChanged(object sender, EventArgs e)
        {
            if (updatingFromWheel) return;

            string hex = txtHex.Text.Trim();
            if (hex.StartsWith("#")) hex = hex.Substring(1);

            if (hex.Length == 6 && IsHexValid(hex))
            {
                try
                {
                    int r = Convert.ToInt32(hex.Substring(0, 2), 16);
                    int g = Convert.ToInt32(hex.Substring(2, 2), 16);
                    int b = Convert.ToInt32(hex.Substring(4, 2), 16);

                    SelectedColor = Color.FromArgb(r, g, b);

                    updatingFromWheel = true;
                    SetInitialPosition(SelectedColor);
                    panelPreview.BackColor = SelectedColor;
                    pictureWheel.Invalidate();
                    updatingFromWheel = false;
                }
                catch { }
            }
        }

        private bool IsHexValid(string hex)
        {
            if (hex.Length != 6) return false;
            foreach (char c in hex)
            {
                if (!((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f')))
                    return false;
            }
            return true;
        }

        private void NumRGB_ValueChanged(object sender, EventArgs e)
        {
            if (updatingFromWheel) return;

            SelectedColor = Color.FromArgb(
                (int)numR.Value,
                (int)numG.Value,
                (int)numB.Value
            );

            updatingFromWheel = true;
            SetInitialPosition(SelectedColor);
            panelPreview.BackColor = SelectedColor;
            pictureWheel.Invalidate();
            updatingFromWheel = false;
        }

        private void SetInitialPosition(Color color)
        {
            float r = color.R / 255f;
            float g = color.G / 255f;
            float b = color.B / 255f;

            float max = Math.Max(r, Math.Max(g, b));
            float min = Math.Min(r, Math.Min(g, b));
            float delta = max - min;

            float hue = 0;
            if (delta != 0)
            {
                if (max == r)
                    hue = ((g - b) / delta) % 6;
                else if (max == g)
                    hue = (b - r) / delta + 2;
                else
                    hue = (r - g) / delta + 4;

                hue *= 60;
                if (hue < 0) hue += 360;
            }

            float saturation = max == 0 ? 0 : delta / max;
            brightness = max;
            trackBrightness.Value = (int)(brightness * 100);

            float angle = (float)(hue * Math.PI / 180.0);
            float radius = saturation * 180;

            selectedPoint.X = (int)(180 + radius * Math.Cos(angle));
            selectedPoint.Y = (int)(180 - radius * Math.Sin(angle));

            updatingFromWheel = true;
            numR.Value = color.R;
            numG.Value = color.G;
            numB.Value = color.B;
            txtHex.Text = $"#{color.R:X2}{color.G:X2}{color.B:X2}";
            updatingFromWheel = false;
        }

        private void GenerateColorWheel()
        {
            colorWheel = new Bitmap(360, 360);
            int centerX = 180;
            int centerY = 180;
            int radius = 180;

            for (int y = 0; y < 360; y++)
            {
                for (int x = 0; x < 360; x++)
                {
                    int dx = x - centerX;
                    int dy = y - centerY;
                    double distance = Math.Sqrt(dx * dx + dy * dy);

                    if (distance <= radius)
                    {
                        double angle = Math.Atan2(-dy, dx);
                        float hue = (float)(angle * 180.0 / Math.PI);
                        if (hue < 0) hue += 360;

                        float saturation = (float)(distance / radius);

                        Color color;
                        if (useOKLAB)
                        {
                            color = OKLABToRGB(hue, saturation, 1.0f);
                        }
                        else
                        {
                            color = HSVToRGB(hue, saturation, 1.0f);
                        }

                        colorWheel.SetPixel(x, y, color);
                    }
                    else
                    {
                        colorWheel.SetPixel(x, y, Color.White);
                    }
                }
            }
        }

        private void PictureWheel_MouseDown(object sender, MouseEventArgs e)
        {
            SelectColor(e.Location);
        }

        private void PictureWheel_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                SelectColor(e.Location);
            }
        }

        private void SelectColor(Point point)
        {
            int dx = point.X - 180;
            int dy = point.Y - 180;
            double distance = Math.Sqrt(dx * dx + dy * dy);

            if (distance <= 180)
            {
                selectedPoint = point;
                UpdatePreview();
                pictureWheel.Invalidate();
            }
        }

        private void PictureWheel_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.DrawEllipse(Pens.Black, selectedPoint.X - 8, selectedPoint.Y - 8, 16, 16);
            e.Graphics.DrawEllipse(Pens.White, selectedPoint.X - 7, selectedPoint.Y - 7, 14, 14);
        }

        private void UpdatePreview()
        {
            if (colorWheel != null && selectedPoint.X >= 0 && selectedPoint.X < 360
                && selectedPoint.Y >= 0 && selectedPoint.Y < 360)
            {
                Color baseColor = colorWheel.GetPixel(selectedPoint.X, selectedPoint.Y);

                int r = (int)(baseColor.R * brightness);
                int g = (int)(baseColor.G * brightness);
                int b = (int)(baseColor.B * brightness);

                SelectedColor = Color.FromArgb(
                    Math.Min(255, r),
                    Math.Min(255, g),
                    Math.Min(255, b)
                );

                panelPreview.BackColor = SelectedColor;

                updatingFromWheel = true;
                numR.Value = SelectedColor.R;
                numG.Value = SelectedColor.G;
                numB.Value = SelectedColor.B;
                txtHex.Text = $"#{SelectedColor.R:X2}{SelectedColor.G:X2}{SelectedColor.B:X2}";
                updatingFromWheel = false;
            }
        }

        private Color HSVToRGB(float hue, float saturation, float value)
        {
            int hi = Convert.ToInt32(Math.Floor(hue / 60)) % 6;
            double f = hue / 60 - Math.Floor(hue / 60);

            value = value * 255;
            int v = Convert.ToInt32(value);
            int p = Convert.ToInt32(value * (1 - saturation));
            int q = Convert.ToInt32(value * (1 - f * saturation));
            int t = Convert.ToInt32(value * (1 - (1 - f) * saturation));

            if (hi == 0)
                return Color.FromArgb(255, v, t, p);
            else if (hi == 1)
                return Color.FromArgb(255, q, v, p);
            else if (hi == 2)
                return Color.FromArgb(255, p, v, t);
            else if (hi == 3)
                return Color.FromArgb(255, p, q, v);
            else if (hi == 4)
                return Color.FromArgb(255, t, p, v);
            else
                return Color.FromArgb(255, v, p, q);
        }

        // OKLAB color space implementation
        private Color OKLABToRGB(float hue, float chroma, float lightness)
        {
            // Convert hue (0-360) and chroma (0-1) to a and b in OKLAB
            float hueRad = hue * (float)Math.PI / 180f;
            float a = chroma * (float)Math.Cos(hueRad) * 0.4f;
            float b = chroma * (float)Math.Sin(hueRad) * 0.4f;
            float L = lightness * 0.8f + 0.2f; // Keep lightness in reasonable range

            // OKLAB to linear RGB
            float l_ = L + 0.3963377774f * a + 0.2158037573f * b;
            float m_ = L - 0.1055613458f * a - 0.0638541728f * b;
            float s_ = L - 0.0894841775f * a - 1.2914855480f * b;

            float l = l_ * l_ * l_;
            float m = m_ * m_ * m_;
            float s = s_ * s_ * s_;

            float r_lin = +4.0767416621f * l - 3.3077115913f * m + 0.2309699292f * s;
            float g_lin = -1.2684380046f * l + 2.6097574011f * m - 0.3413193965f * s;
            float b_lin = -0.0041960863f * l - 0.7034186147f * m + 1.7076147010f * s;

            // Linear RGB to sRGB (gamma correction)
            int r = (int)(LinearToSRGB(r_lin) * 255);
            int g = (int)(LinearToSRGB(g_lin) * 255);
            int b_val = (int)(LinearToSRGB(b_lin) * 255);

            r = Math.Max(0, Math.Min(255, r));
            g = Math.Max(0, Math.Min(255, g));
            b_val = Math.Max(0, Math.Min(255, b_val));

            return Color.FromArgb(r, g, b_val);
        }

        private float LinearToSRGB(float linear)
        {
            if (linear <= 0.0031308f)
                return 12.92f * linear;
            else
                return 1.055f * (float)Math.Pow(linear, 1.0f / 2.4f) - 0.055f;
        }
    }
}