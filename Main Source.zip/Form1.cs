﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Textural;

namespace TextureGeneratorGUI
{
    public partial class Form1 : Form
    {
        [DllImport("TextGenCore.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Unicode)]
        private static extern int TestDLL();

        [DllImport("TextGenCore.dll", CallingConvention = CallingConvention.StdCall, CharSet = CharSet.Unicode)]
        private static extern int GenerateTexture(
        int width, int height,
        int noiseType, float scale, int octaves, float persistence, float lacunarity,
        int colorMode, int patternType, float patternParam,
        int overlayType, float overlayParam1, float overlayParam2,
        uint seed,
        float contrast, float brightness, int invert,
        int tileable,
        float normalStrength,
        float specularSmoothness,
        int exportRoughness,
        int exportMetallic,
        [MarshalAs(UnmanagedType.LPWStr)] string outputPath
        );

        private string lastGeneratedPath = "";
        private Bitmap importedTexture = null; // Store imported texture
        private bool isGenerating = false;
        private System.Windows.Forms.Timer debounceTimer;

        private Color customColor1 = Color.FromArgb(139, 69, 19);
        private Color customColor2 = Color.FromArgb(205, 133, 63);
        private Color customColor3 = Color.FromArgb(222, 184, 135);

        // Layer system
        private List<TextureLayer> textureLayers = new List<TextureLayer>();
        private Bitmap currentGeneratedTexture = null;

        // Add these controls in designer:
        // Button btnOpenLayerManager
        // Button btnAddAsLayer
        // CheckBox checkUseLayerSystem

        // Add these controls in designer:
        // CheckBox checkTileable
        // CheckBox checkShow2x2 - for showing 2x2 tiled preview
        // TrackBar trackNormalStrength (Min: 10, Max: 100, Value: 30) - for 1.0-10.0 range
        // Label lblNormalStrength, lblNormalStrengthValue
        // TrackBar trackSpecSmooth (Min: 0, Max: 100, Value: 70) - for 0.0-1.0 range
        // Label lblSpecSmooth, lblSpecSmoothValue
        // CheckBox checkExportRoughness
        // CheckBox checkExportMetallic

        private void TriggerDebouncedPreview()
        {
            debounceTimer?.Stop();
            debounceTimer?.Dispose();

            debounceTimer = new System.Windows.Forms.Timer();
            debounceTimer.Interval = 300;
            debounceTimer.Tick += (s, e) =>
            {
                debounceTimer.Stop();
                GeneratePreview();
            };
            debounceTimer.Start();
        }

        private void GeneratePreview()
        {
            if (isGenerating) return;

            try
            {
                isGenerating = true;

                int previewWidth = 256;
                int previewHeight = 256;

                string tempPath = Path.Combine(Path.GetTempPath(), "preview_texture.png");

                int noiseType = comboNoiseType.SelectedIndex + 1;
                float scale = (float)numScale.Value;
                int octaves = trackOctaves.Value;
                float persistence = trackPersistence.Value / 10.0f;
                float lacunarity = trackLacunarity.Value / 10.0f;
                int colorMode = comboColor.SelectedIndex + 1;
                int patternType = comboPattern.SelectedIndex + 1;
                float patternParam = trackPatternParam.Value;

                if (patternType == 4)
                {
                    patternParam = patternParam / 10.0f;
                }

                int overlayType = 0;
                float overlayParam1 = 0;
                float overlayParam2 = 0;

                if (checkEnableOverlay.Checked)
                {
                    overlayType = comboOverlay.SelectedIndex + 1;
                    overlayParam1 = trackOverlayParam1.Value;

                    if (overlayType == 1) // Marble veins
                    {
                        overlayParam2 = trackOverlayIntensity.Value / 10.0f;
                    }
                    else if (overlayType == 2) // Bricks
                    {
                        overlayParam2 = trackOverlayParam2.Value;
                    }
                    else if (overlayType == 3) // Planks
                    {
                        overlayParam2 = checkPlankUniqueGrain.Checked ? 1.0f : 0.0f;
                    }
                }

                float contrast = 1.0f;
                float brightness = 0.0f;
                int invert = 0;

                if (checkEnableEffects.Checked)
                {
                    contrast = trackContrast.Value / 10.0f;
                    brightness = trackBrightness.Value / 10.0f;
                    invert = checkInvert.Checked ? 1 : 0;
                }

                uint seed = (uint)numSeed.Value;
                int tileable = checkTileable.Checked ? 1 : 0;
                float normalStrength = trackNormalStrength.Value / 10.0f;
                float specSmooth = trackSpecSmooth.Value / 100.0f;
                int exportRoughness = 0; // Don't export for preview
                int exportMetallic = 0;  // Don't export for preview

                int result = GenerateTexture(
                    previewWidth, previewHeight,
                    noiseType, scale, octaves, persistence, lacunarity,
                    colorMode, patternType, patternParam,
                    overlayType, overlayParam1, overlayParam2,
                    seed,
                    contrast, brightness, invert,
                    tileable,
                    normalStrength,
                    specSmooth,
                    exportRoughness,
                    exportMetallic,
                    tempPath
                );

                if (result == 1)
                {
                    string diffPath = tempPath.Replace(".png", "_diff.png");

                    if (comboColor.SelectedIndex == 7)
                    {
                        ApplyCustomGradient(diffPath, customColor1, customColor2, customColor3);
                    }

                    if (File.Exists(diffPath))
                    {
                        if (picturePreview.Image != null)
                        {
                            picturePreview.Image.Dispose();
                        }

                        using (var fs = new FileStream(diffPath, FileMode.Open, FileAccess.Read))
                        {
                            Bitmap originalImage = new Bitmap(fs);

                            // Store for layer system
                            currentGeneratedTexture?.Dispose();
                            currentGeneratedTexture = new Bitmap(originalImage);

                            // Check if we should show 2x2 tiled preview
                            if (checkShow2x2.Checked)
                            {
                                picturePreview.Image = Create2x2TiledImage(originalImage);
                                originalImage.Dispose();
                            }
                            else
                            {
                                picturePreview.Image = originalImage;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Preview error: {ex.Message}");
            }
            finally
            {
                isGenerating = false;
            }
        }

        public Form1()
        {
            InitializeComponent();
            InitializeForm();
        }

        private void InitializeForm()
        {
            comboNoiseType.SelectedIndex = 1;
            comboPattern.SelectedIndex = 0;
            comboColor.SelectedIndex = 0;
            comboOverlay.SelectedIndex = 0;

            btnColor1.BackColor = customColor1;
            btnColor2.BackColor = customColor2;
            btnColor3.BackColor = customColor3;

            // Wire up slider events
            trackOctaves.Scroll += (s, e) => {
                lblOctavesValue.Text = trackOctaves.Value.ToString();
                TriggerDebouncedPreview();
            };
            trackPersistence.Scroll += (s, e) => {
                lblPersistenceValue.Text = (trackPersistence.Value / 10.0).ToString("0.0");
                TriggerDebouncedPreview();
            };
            trackLacunarity.Scroll += (s, e) => {
                lblLacunarityValue.Text = (trackLacunarity.Value / 10.0).ToString("0.0");
                TriggerDebouncedPreview();
            };
            trackPatternParam.Scroll += (s, e) => {
                lblPatternParamValue.Text = trackPatternParam.Value.ToString();
                TriggerDebouncedPreview();
            };
            trackOverlayIntensity.Scroll += (s, e) => {
                lblOverlayIntensityValue.Text = (trackOverlayIntensity.Value / 10.0).ToString("0.0");
                TriggerDebouncedPreview();
            };
            trackOverlayParam1.Scroll += (s, e) => {
                lblOverlayParam1Value.Text = trackOverlayParam1.Value.ToString();
                TriggerDebouncedPreview();
            };
            trackOverlayParam2.Scroll += (s, e) => {
                lblOverlayParam2Value.Text = trackOverlayParam2.Value.ToString();
                TriggerDebouncedPreview();
            };
            trackContrast.Scroll += (s, e) => {
                lblContrastValue.Text = (trackContrast.Value / 10.0).ToString("0.0");
                TriggerDebouncedPreview();
            };
            trackBrightness.Scroll += (s, e) => {
                lblBrightnessValue.Text = (trackBrightness.Value / 10.0).ToString("0.0");
                TriggerDebouncedPreview();
            };

            trackNormalStrength.Scroll += (s, e) => {
                lblNormalStrengthValue.Text = (trackNormalStrength.Value / 10.0).ToString("0.0");
                TriggerDebouncedPreview();
            };

            trackSpecSmooth.Scroll += (s, e) => {
                lblSpecSmoothValue.Text = (trackSpecSmooth.Value / 100.0).ToString("0.00");
                TriggerDebouncedPreview();
            };

            // Wire up other controls
            comboNoiseType.SelectedIndexChanged += (s, e) => GeneratePreview();
            comboPattern.SelectedIndexChanged += (s, e) => {
                if (comboPattern.SelectedIndex == 3)
                {
                    trackPatternParam.Minimum = 10;
                    trackPatternParam.Maximum = 30;
                    trackPatternParam.Value = 15;
                }
                else
                {
                    trackPatternParam.Minimum = 20;
                    trackPatternParam.Maximum = 150;
                    trackPatternParam.Value = 50;
                }
                GeneratePreview();
            };
            comboColor.SelectedIndexChanged += (s, e) => {
                bool isCustom = (comboColor.SelectedIndex == 7);
                lblColor1.Visible = isCustom;
                btnColor1.Visible = isCustom;
                lblColor2.Visible = isCustom;
                btnColor2.Visible = isCustom;
                lblColor3.Visible = isCustom;
                btnColor3.Visible = isCustom;

                GeneratePreview();
            };
            comboOverlay.SelectedIndexChanged += (s, e) => GeneratePreview();

            numWidth.ValueChanged += (s, e) => GeneratePreview();
            numHeight.ValueChanged += (s, e) => GeneratePreview();
            numScale.ValueChanged += (s, e) => GeneratePreview();
            numSeed.ValueChanged += (s, e) => GeneratePreview();

            checkEnableOverlay.CheckedChanged += (s, e) => {
                comboOverlay.Enabled = checkEnableOverlay.Checked;
                trackOverlayIntensity.Enabled = checkEnableOverlay.Checked;
                trackOverlayParam1.Enabled = checkEnableOverlay.Checked;
                trackOverlayParam2.Enabled = checkEnableOverlay.Checked;
                GeneratePreview();
            };

            checkEnableEffects.CheckedChanged += (s, e) => {
                trackContrast.Enabled = checkEnableEffects.Checked;
                trackBrightness.Enabled = checkEnableEffects.Checked;
                checkInvert.Enabled = checkEnableEffects.Checked;
                GeneratePreview();
            };

            checkInvert.CheckedChanged += (s, e) => GeneratePreview();
            checkTileable.CheckedChanged += (s, e) => GeneratePreview();  // NEW
            checkShow2x2.CheckedChanged += (s, e) => GeneratePreview();   // NEW - regenerate preview when toggling 2x2

            btnRandomSeed.Click += (s, e) => {
                numSeed.Value = new Random().Next(0, 999999);
                GeneratePreview();
            };

            btnGenerate.Click += BtnGenerate_Click;
            btnSave.Click += BtnSave_Click;

            // Layer system buttons
            btnOpenLayerManager.Click += BtnOpenLayerManager_Click;
            btnAddAsLayer.Click += BtnAddAsLayer_Click;
            checkUseLayerSystem.CheckedChanged += (s, e) => {
                btnAddAsLayer.Enabled = checkUseLayerSystem.Checked;
                btnOpenLayerManager.Enabled = checkUseLayerSystem.Checked;
            };


            btnSaveSession.Click += BtnSaveSession_Click;
            btnLoadSession.Click += BtnLoadSession_Click;

            checkAutoSave.CheckedChanged += (s, e) => {
                SessionManager.AutoSaveEnabled = checkAutoSave.Checked;
            };

            // Wire up plank unique grain checkbox
            checkPlankUniqueGrain.CheckedChanged += (s, e) => GeneratePreview();

            // Show/hide plank grain checkbox based on overlay type
            comboOverlay.SelectedIndexChanged += (s, e) => {
                bool isPlanks = (comboOverlay.SelectedIndex == 2); // Index 2 = Planks (third item)
                checkPlankUniqueGrain.Visible = isPlanks;
                checkPlankUniqueGrain.Enabled = isPlanks;
                GeneratePreview();
            };

            // Import texture buttons
            btnImportTexture.Click += BtnImportTexture_Click;
            btnApplyToImported.Click += BtnApplyToImported_Click;
            btnMakeTileable.Click += BtnMakeTileable_Click;


            btnColor1.Click += (s, e) =>
            {
                ColorWheelForm cwf = new ColorWheelForm(customColor1);
                if (cwf.ShowDialog() == DialogResult.OK)
                {
                    customColor1 = cwf.SelectedColor;
                    btnColor1.BackColor = customColor1;
                    GeneratePreview();
                }
            };

            btnColor2.Click += (s, e) =>
            {
                ColorWheelForm cwf = new ColorWheelForm(customColor2);
                if (cwf.ShowDialog() == DialogResult.OK)
                {
                    customColor2 = cwf.SelectedColor;
                    btnColor2.BackColor = customColor2;
                    GeneratePreview();
                }
            };

            btnColor3.Click += (s, e) =>
            {
                ColorWheelForm cwf = new ColorWheelForm(customColor3);
                if (cwf.ShowDialog() == DialogResult.OK)
                {
                    customColor3 = cwf.SelectedColor;
                    btnColor3.BackColor = customColor3;
                    GeneratePreview();
                }
            };

            try
            {
                int result = TestDLL();
                if (result != 42)
                {
                    MessageBox.Show("DLL test failed! Make sure TextGenCore.dll is in the correct location.", "Error");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Cannot load DLL: {ex.Message}\n\nMake sure TextGenCore.dll is next to the executable.", "DLL Error");
            }

            GeneratePreview();
        }

        private void ApplyCustomGradient(string imagePath, Color color1, Color color2, Color color3)
        {
            try
            {
                Bitmap grayscale;
                using (var fs = new FileStream(imagePath, FileMode.Open, FileAccess.Read))
                {
                    grayscale = new Bitmap(fs);
                }

                Bitmap colored = new Bitmap(grayscale.Width, grayscale.Height, PixelFormat.Format24bppRgb);

                for (int y = 0; y < grayscale.Height; y++)
                {
                    for (int x = 0; x < grayscale.Width; x++)
                    {
                        Color pixel = grayscale.GetPixel(x, y);
                        float value = pixel.R / 255f;

                        Color finalColor;
                        if (value < 0.5f)
                        {
                            float t = value * 2f;
                            finalColor = InterpolateColor(color1, color2, t);
                        }
                        else
                        {
                            float t = (value - 0.5f) * 2f;
                            finalColor = InterpolateColor(color2, color3, t);
                        }

                        colored.SetPixel(x, y, finalColor);
                    }
                }

                grayscale.Dispose();
                colored.Save(imagePath, ImageFormat.Png);
                colored.Dispose();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error applying gradient: {ex.Message}");
            }
        }

        private Color InterpolateColor(Color c1, Color c2, float t)
        {
            t = Math.Max(0, Math.Min(1, t));
            int r = (int)(c1.R + (c2.R - c1.R) * t);
            int g = (int)(c1.G + (c2.G - c1.G) * t);
            int b = (int)(c1.B + (c2.B - c1.B) * t);
            return Color.FromArgb(r, g, b);
        }

        private Bitmap Create2x2TiledImage(Bitmap original)
        {
            int width = original.Width;
            int height = original.Height;

            // Create a new bitmap that's 2x2 the original size
            Bitmap tiled = new Bitmap(width * 2, height * 2);

            using (Graphics g = Graphics.FromImage(tiled))
            {
                // Draw the original texture 4 times in a 2x2 grid
                g.DrawImage(original, 0, 0, width, height);           // Top-left
                g.DrawImage(original, width, 0, width, height);       // Top-right
                g.DrawImage(original, 0, height, width, height);      // Bottom-left
                g.DrawImage(original, width, height, width, height);  // Bottom-right
            }

            return tiled;
        }

        private void BtnGenerate_Click(object sender, EventArgs e)
        {
            try
            {
                string tempPath = Path.Combine(Path.GetTempPath(), "temp_texture.png");

                int width = (int)numWidth.Value;
                int height = (int)numHeight.Value;
                int noiseType = comboNoiseType.SelectedIndex + 1;
                float scale = (float)numScale.Value;
                int octaves = trackOctaves.Value;
                float persistence = trackPersistence.Value / 10.0f;
                float lacunarity = trackLacunarity.Value / 10.0f;
                int colorMode = comboColor.SelectedIndex + 1;
                int patternType = comboPattern.SelectedIndex + 1;
                float patternParam = trackPatternParam.Value;

                if (patternType == 4)
                {
                    patternParam = patternParam / 10.0f;
                }

                int overlayType = 0;
                float overlayParam1 = 0;
                float overlayParam2 = 0;

                if (checkEnableOverlay.Checked)
                {
                    overlayType = comboOverlay.SelectedIndex + 1;
                    overlayParam1 = trackOverlayParam1.Value;

                    if (overlayType == 1) // Marble veins
                    {
                        overlayParam2 = trackOverlayIntensity.Value / 10.0f;
                    }
                    else if (overlayType == 2) // Bricks
                    {
                        overlayParam2 = trackOverlayParam2.Value;
                    }
                    else if (overlayType == 3) // Planks
                    {
                        overlayParam2 = checkPlankUniqueGrain.Checked ? 1.0f : 0.0f;
                    }
                }

                uint seed = (uint)numSeed.Value;

                btnGenerate.Enabled = false;
                btnGenerate.Text = "Generating...";
                Application.DoEvents();

                float contrast = 1.0f;
                float brightness = 0.0f;
                int invert = 0;

                if (checkEnableEffects.Checked)
                {
                    contrast = trackContrast.Value / 10.0f;
                    brightness = trackBrightness.Value / 10.0f;
                    invert = checkInvert.Checked ? 1 : 0;
                }

                int tileable = checkTileable.Checked ? 1 : 0;  // NEW
                float normalStrength = trackNormalStrength.Value / 10.0f;
                float specSmooth = trackSpecSmooth.Value / 100.0f;
                int exportRoughness = checkExportRoughness.Checked ? 1 : 0;
                int exportMetallic = checkExportMetallic.Checked ? 1 : 0;

                int result = GenerateTexture(
                    width, height,
                    noiseType, scale, octaves, persistence, lacunarity,
                    colorMode, patternType, patternParam,
                    overlayType, overlayParam1, overlayParam2,
                    seed,
                    contrast, brightness, invert,
                    tileable,
                    normalStrength,
                    specSmooth,
                    exportRoughness,
                    exportMetallic,
                    tempPath
                );

                btnGenerate.Enabled = true;
                btnGenerate.Text = "Generate Texture";

                if (result == 1)
                {
                    string diffPath = tempPath.Replace(".png", "_diff.png");

                    if (comboColor.SelectedIndex == 7)
                    {
                        ApplyCustomGradient(diffPath, customColor1, customColor2, customColor3);
                    }

                    if (File.Exists(diffPath))
                    {
                        if (picturePreview.Image != null)
                        {
                            picturePreview.Image.Dispose();
                        }

                        using (var fs = new FileStream(diffPath, FileMode.Open, FileAccess.Read))
                        {
                            Bitmap originalImage = new Bitmap(fs);

                            // Store for layer system
                            currentGeneratedTexture?.Dispose();
                            currentGeneratedTexture = new Bitmap(originalImage);

                            // Check if we should show 2x2 tiled preview
                            if (checkShow2x2.Checked)
                            {
                                picturePreview.Image = Create2x2TiledImage(originalImage);
                                originalImage.Dispose();
                            }
                            else
                            {
                                picturePreview.Image = originalImage;
                            }
                        }

                        lastGeneratedPath = tempPath;
                        btnSave.Enabled = true;
                        btnAddAsLayer.Enabled = checkUseLayerSystem.Checked; // Enable add to layer

                        // Build message with generated maps
                        string message = "Generated textures:\n• _diff.png (Diffuse/Albedo)\n• _nmap.png (Normal Map)\n• _spec.png (Specular)";

                        if (checkExportRoughness.Checked)
                            message += "\n• _rough.png (Roughness)";

                        if (checkExportMetallic.Checked)
                            message += "\n• _metal.png (Metallic)";

                        MessageBox.Show(message, "Success!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error");
                btnGenerate.Enabled = true;
                btnGenerate.Text = "Generate Texture";
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(lastGeneratedPath))
            {
                MessageBox.Show("No texture to save!", "Error");
                return;
            }

            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "PNG Image|*.png";
            sfd.FileName = "texture.png";
            sfd.Title = "Save Texture Set";
            sfd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string basePath = sfd.FileName.Replace(".png", "");
                    string tempBase = lastGeneratedPath.Replace(".png", "");

                    // Copy base maps
                    File.Copy(tempBase + "_diff.png", basePath + "_diff.png", true);
                    File.Copy(tempBase + "_nmap.png", basePath + "_nmap.png", true);
                    File.Copy(tempBase + "_spec.png", basePath + "_spec.png", true);

                    string message = $"Saved textures to:\n{Path.GetDirectoryName(basePath)}\n\n";
                    message += $"• {Path.GetFileName(basePath)}_diff.png\n";
                    message += $"• {Path.GetFileName(basePath)}_nmap.png\n";
                    message += $"• {Path.GetFileName(basePath)}_spec.png";

                    // Only copy if checkbox was checked AND file exists
                    if (checkExportRoughness.Checked && File.Exists(tempBase + "_rough.png"))
                    {
                        File.Copy(tempBase + "_rough.png", basePath + "_rough.png", true);
                        message += $"\n• {Path.GetFileName(basePath)}_rough.png";
                    }

                    if (checkExportMetallic.Checked && File.Exists(tempBase + "_metal.png"))
                    {
                        File.Copy(tempBase + "_metal.png", basePath + "_metal.png", true);
                        message += $"\n• {Path.GetFileName(basePath)}_metal.png";
                    }

                    MessageBox.Show(message, "Textures Saved Successfully");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Failed to save: {ex.Message}", "Error");
                }
            }
        }

        private void BtnAddAsLayer_Click(object sender, EventArgs e)
        {
            if (currentGeneratedTexture == null)
            {
                MessageBox.Show("Generate a texture first!", "Error");
                return;
            }

            string layerName = $"Layer {textureLayers.Count + 1}";
            var newLayer = new TextureLayer(layerName, new Bitmap(currentGeneratedTexture));
            textureLayers.Add(newLayer);

            MessageBox.Show($"Added as {layerName}. Open Layer Manager to blend.", "Success");
        }

        private void BtnOpenLayerManager_Click(object sender, EventArgs e)
        {
            LayerManagerForm layerForm = new LayerManagerForm(textureLayers);

            if (layerForm.ShowDialog() == DialogResult.OK)
            {
                // Update layers
                textureLayers = layerForm.Layers;

                // Composite and show result
                if (textureLayers.Count > 0)
                {
                    Bitmap composite = LayerCompositor.CompositeLayers(textureLayers);

                    if (composite != null)
                    {
                        picturePreview.Image?.Dispose();
                        picturePreview.Image = composite;

                        currentGeneratedTexture?.Dispose();
                        currentGeneratedTexture = new Bitmap(composite);

                        // Save composite to temp files so it can be saved properly
                        string tempPath = Path.Combine(Path.GetTempPath(), "layered_texture.png");
                        string diffPath = tempPath.Replace(".png", "_diff.png");

                        composite.Save(diffPath, System.Drawing.Imaging.ImageFormat.Png);

                        // Also generate normal and spec maps from the composite
                        GenerateMapsFromComposite(composite, tempPath);

                        lastGeneratedPath = tempPath;
                        btnSave.Enabled = true;

                        MessageBox.Show($"Composited {textureLayers.Count} layer(s)", "Layer Composite");
                    }
                }
            }
        }

        private void GenerateMapsFromComposite(Bitmap composite, string basePath)
        {
            // Convert composite to grayscale heightmap
            float[] heightMap = new float[composite.Width * composite.Height];

            for (int y = 0; y < composite.Height; y++)
            {
                for (int x = 0; x < composite.Width; x++)
                {
                    Color pixel = composite.GetPixel(x, y);
                    // Convert to grayscale
                    heightMap[y * composite.Width + x] = (pixel.R * 0.299f + pixel.G * 0.587f + pixel.B * 0.114f) / 255f;
                }
            }

            // Generate normal map
            Bitmap normalMap = new Bitmap(composite.Width, composite.Height);
            float strength = trackNormalStrength.Value / 10.0f;

            for (int y = 0; y < composite.Height; y++)
            {
                for (int x = 0; x < composite.Width; x++)
                {
                    int xLeft = Math.Max(0, x - 1);
                    int xRight = Math.Min(composite.Width - 1, x + 1);
                    int yUp = Math.Max(0, y - 1);
                    int yDown = Math.Min(composite.Height - 1, y + 1);

                    float hL = heightMap[y * composite.Width + xLeft];
                    float hR = heightMap[y * composite.Width + xRight];
                    float hU = heightMap[yUp * composite.Width + x];
                    float hD = heightMap[yDown * composite.Width + x];

                    float dx = (hR - hL) * strength;
                    float dy = (hD - hU) * strength;

                    float nx = -dx;
                    float ny = -dy;
                    float nz = 1.0f;

                    float length = (float)Math.Sqrt(nx * nx + ny * ny + nz * nz);
                    nx /= length;
                    ny /= length;
                    nz /= length;

                    int r = (int)(((nx + 1.0f) * 0.5f) * 255);
                    int g = (int)(((ny + 1.0f) * 0.5f) * 255);
                    int b = (int)(((nz + 1.0f) * 0.5f) * 255);

                    normalMap.SetPixel(x, y, Color.FromArgb(r, g, b));
                }
            }

            string nmapPath = basePath.Replace(".png", "_nmap.png");
            normalMap.Save(nmapPath, System.Drawing.Imaging.ImageFormat.Png);
            normalMap.Dispose();

            // Generate specular map
            Bitmap specMap = new Bitmap(composite.Width, composite.Height);
            float specSmooth = trackSpecSmooth.Value / 100.0f;

            for (int y = 0; y < composite.Height; y++)
            {
                for (int x = 0; x < composite.Width; x++)
                {
                    float h = heightMap[y * composite.Width + x];
                    float spec = (1.0f - h * 0.7f) * specSmooth;
                    int specValue = (int)(spec * 255);
                    specMap.SetPixel(x, y, Color.FromArgb(specValue, specValue, specValue));
                }
            }

            string specPath = basePath.Replace(".png", "_spec.png");
            specMap.Save(specPath, System.Drawing.Imaging.ImageFormat.Png);
            specMap.Dispose();

            // Generate optional maps if checked
            if (checkExportRoughness.Checked)
            {
                Bitmap roughMap = new Bitmap(composite.Width, composite.Height);
                for (int y = 0; y < composite.Height; y++)
                {
                    for (int x = 0; x < composite.Width; x++)
                    {
                        float h = heightMap[y * composite.Width + x];
                        float rough = h * 0.7f + (1.0f - specSmooth) * 0.3f;
                        int roughValue = (int)(rough * 255);
                        roughMap.SetPixel(x, y, Color.FromArgb(roughValue, roughValue, roughValue));
                    }
                }
                string roughPath = basePath.Replace(".png", "_rough.png");
                roughMap.Save(roughPath, System.Drawing.Imaging.ImageFormat.Png);
                roughMap.Dispose();
            }

            if (checkExportMetallic.Checked)
            {
                Bitmap metalMap = new Bitmap(composite.Width, composite.Height);
                for (int y = 0; y < composite.Height; y++)
                {
                    for (int x = 0; x < composite.Width; x++)
                    {
                        float h = heightMap[y * composite.Width + x];
                        float metal = (1.0f - h) * 0.5f;
                        int metalValue = (int)(metal * 255);
                        metalMap.SetPixel(x, y, Color.FromArgb(metalValue, metalValue, metalValue));
                    }
                }
                string metalPath = basePath.Replace(".png", "_metal.png");
                metalMap.Save(metalPath, System.Drawing.Imaging.ImageFormat.Png);
                metalMap.Dispose();
            }
        }
        private TextureSession CaptureCurrentSession()
        {
            var session = new TextureSession
            {
                Width = (int)numWidth.Value,
                Height = (int)numHeight.Value,
                NoiseType = comboNoiseType.SelectedIndex + 1,
                Scale = (float)numScale.Value,
                Seed = (int)numSeed.Value,

                Octaves = trackOctaves.Value,
                Persistence = trackPersistence.Value / 10.0f,
                Lacunarity = trackLacunarity.Value / 10.0f,

                PatternType = comboPattern.SelectedIndex + 1,
                PatternParam = trackPatternParam.Value,

                ColorMode = comboColor.SelectedIndex + 1,
                CustomColor1R = customColor1.R,
                CustomColor1G = customColor1.G,
                CustomColor1B = customColor1.B,
                CustomColor2R = customColor2.R,
                CustomColor2G = customColor2.G,
                CustomColor2B = customColor2.B,
                CustomColor3R = customColor3.R,
                CustomColor3G = customColor3.G,
                CustomColor3B = customColor3.B,

                OverlayEnabled = checkEnableOverlay.Checked,
                OverlayType = comboOverlay.SelectedIndex + 1,
                OverlayParam1 = trackOverlayParam1.Value,
                OverlayParam2 = trackOverlayParam2.Value,
                OverlayIntensity = trackOverlayIntensity.Value / 10.0f,

                EffectsEnabled = checkEnableEffects.Checked,
                Contrast = trackContrast.Value / 10.0f,
                Brightness = trackBrightness.Value / 10.0f,
                Invert = checkInvert.Checked,

                Tileable = checkTileable.Checked,
                NormalStrength = trackNormalStrength.Value / 10.0f,
                SpecularSmoothness = trackSpecSmooth.Value / 100.0f,
                ExportRoughness = checkExportRoughness.Checked,
                ExportMetallic = checkExportMetallic.Checked,

                UseLayerSystem = checkUseLayerSystem.Checked,
                SessionName = "Unnamed Session"
            };

            return session;
        }

        private void LoadSessionData(TextureSession session)
        {
            numWidth.Value = session.Width;
            numHeight.Value = session.Height;
            comboNoiseType.SelectedIndex = session.NoiseType - 1;
            numScale.Value = (decimal)session.Scale;
            numSeed.Value = session.Seed;

            trackOctaves.Value = session.Octaves;
            trackPersistence.Value = (int)(session.Persistence * 10);
            trackLacunarity.Value = (int)(session.Lacunarity * 10);

            comboPattern.SelectedIndex = session.PatternType - 1;
            trackPatternParam.Value = (int)session.PatternParam;

            comboColor.SelectedIndex = session.ColorMode - 1;
            customColor1 = Color.FromArgb(session.CustomColor1R, session.CustomColor1G, session.CustomColor1B);
            customColor2 = Color.FromArgb(session.CustomColor2R, session.CustomColor2G, session.CustomColor2B);
            customColor3 = Color.FromArgb(session.CustomColor3R, session.CustomColor3G, session.CustomColor3B);
            btnColor1.BackColor = customColor1;
            btnColor2.BackColor = customColor2;
            btnColor3.BackColor = customColor3;

            checkEnableOverlay.Checked = session.OverlayEnabled;
            comboOverlay.SelectedIndex = session.OverlayType - 1;
            trackOverlayParam1.Value = (int)session.OverlayParam1;
            trackOverlayParam2.Value = (int)session.OverlayParam2;
            trackOverlayIntensity.Value = (int)(session.OverlayIntensity * 10);

            checkEnableEffects.Checked = session.EffectsEnabled;
            trackContrast.Value = (int)(session.Contrast * 10);
            trackBrightness.Value = (int)(session.Brightness * 10);
            checkInvert.Checked = session.Invert;

            checkTileable.Checked = session.Tileable;
            trackNormalStrength.Value = (int)(session.NormalStrength * 10);
            trackSpecSmooth.Value = (int)(session.SpecularSmoothness * 100);
            checkExportRoughness.Checked = session.ExportRoughness;
            checkExportMetallic.Checked = session.ExportMetallic;

            checkUseLayerSystem.Checked = session.UseLayerSystem;

            GeneratePreview();
        }

        private void BtnSaveSession_Click(object sender, EventArgs e)
        {
            using (var dialog = new Form())
            {
                dialog.Text = "Save Session";
                dialog.Width = 400;
                dialog.Height = 150;
                dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
                dialog.StartPosition = FormStartPosition.CenterParent;
                dialog.MaximizeBox = false;
                dialog.MinimizeBox = false;

                var label = new Label { Text = "Session Name:", Left = 20, Top = 20, Width = 100 };
                var textBox = new TextBox { Left = 130, Top = 20, Width = 230 };
                var btnOK = new Button { Text = "Save", Left = 130, Top = 60, Width = 100, DialogResult = DialogResult.OK };
                var btnCancel = new Button { Text = "Cancel", Left = 240, Top = 60, Width = 100, DialogResult = DialogResult.Cancel };

                dialog.Controls.AddRange(new Control[] { label, textBox, btnOK, btnCancel });
                dialog.AcceptButton = btnOK;
                dialog.CancelButton = btnCancel;

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    string sessionName = textBox.Text.Trim();
                    if (string.IsNullOrEmpty(sessionName))
                    {
                        MessageBox.Show("Please enter a session name!", "Error");
                        return;
                    }

                    var session = CaptureCurrentSession();
                    session.SessionName = sessionName;

                    if (SessionManager.SaveSession(session, sessionName))
                    {
                        MessageBox.Show($"Session '{sessionName}' saved successfully!", "Success");
                    }
                    else
                    {
                        MessageBox.Show("Failed to save session!", "Error");
                    }
                }
            }
        }

        private void BtnLoadSession_Click(object sender, EventArgs e)
        {
            var sessions = SessionManager.GetAllSessions();

            if (sessions.Length == 0)
            {
                MessageBox.Show("No saved sessions found!", "Info");
                return;
            }

            using (var dialog = new Form())
            {
                dialog.Text = "Load Session";
                dialog.Width = 400;
                dialog.Height = 300;
                dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
                dialog.StartPosition = FormStartPosition.CenterParent;
                dialog.MaximizeBox = false;
                dialog.MinimizeBox = false;

                var listBox = new ListBox { Left = 20, Top = 20, Width = 340, Height = 180 };
                listBox.Items.AddRange(sessions);

                var btnLoad = new Button { Text = "Load", Left = 130, Top = 220, Width = 100, DialogResult = DialogResult.OK };
                var btnDelete = new Button { Text = "Delete", Left = 240, Top = 220, Width = 100 };
                var btnCancel = new Button { Text = "Cancel", Left = 20, Top = 220, Width = 100, DialogResult = DialogResult.Cancel };

                btnDelete.Click += (sender2, e2) => {
                    if (listBox.SelectedItem != null)
                    {
                        var result = MessageBox.Show($"Delete session '{listBox.SelectedItem}'?", "Confirm", MessageBoxButtons.YesNo);
                        if (result == DialogResult.Yes)
                        {
                            SessionManager.DeleteSession(listBox.SelectedItem.ToString());
                            listBox.Items.Remove(listBox.SelectedItem);
                        }
                    }
                };

                dialog.Controls.AddRange(new Control[] { listBox, btnLoad, btnDelete, btnCancel });
                dialog.AcceptButton = btnLoad;
                dialog.CancelButton = btnCancel;

                if (dialog.ShowDialog() == DialogResult.OK && listBox.SelectedItem != null)
                {
                    var session = SessionManager.LoadSession(listBox.SelectedItem.ToString());
                    if (session != null)
                    {
                        LoadSessionData(session);
                        MessageBox.Show($"Loaded session '{session.SessionName}'!", "Success");
                    }
                    else
                    {
                        MessageBox.Show("Failed to load session!", "Error");
                    }
                }
            }
        }
        private void BtnImportTexture_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = TextureImporter.GetSupportedFormats();
            ofd.Title = "Import Texture";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    int targetWidth = (int)numWidth.Value;
                    int targetHeight = (int)numHeight.Value;

                    var result = MessageBox.Show(
                        $"Resize to {targetWidth}x{targetHeight}?\n\nYes = Resize\nNo = Keep original size",
                        "Resize Image?",
                        MessageBoxButtons.YesNoCancel
                    );

                    if (result == DialogResult.Cancel)
                        return;

                    Bitmap imported;
                    if (result == DialogResult.Yes)
                    {
                        imported = TextureImporter.ImportTexture(ofd.FileName, targetWidth, targetHeight);
                    }
                    else
                    {
                        imported = TextureImporter.ImportTexture(ofd.FileName);
                        numWidth.Value = imported.Width;
                        numHeight.Value = imported.Height;
                    }

                    if (imported != null)
                    {
                        importedTexture?.Dispose();
                        importedTexture = imported;

                        picturePreview.Image?.Dispose();
                        picturePreview.Image = new Bitmap(imported);

                        currentGeneratedTexture?.Dispose();
                        currentGeneratedTexture = new Bitmap(imported);

                        btnApplyToImported.Enabled = true;
                        btnMakeTileable.Enabled = true;
                        btnAddAsLayer.Enabled = checkUseLayerSystem.Checked;

                        MessageBox.Show($"Imported: {Path.GetFileName(ofd.FileName)}\nSize: {imported.Width}x{imported.Height}", "Success");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Import error: {ex.Message}", "Error");
                }
            }
        }

        private void BtnApplyToImported_Click(object sender, EventArgs e)
        {
            if (importedTexture == null)
            {
                MessageBox.Show("Import a texture first!", "Error");
                return;
            }

            try
            {
                Bitmap processed = new Bitmap(importedTexture);

                if (checkEnableEffects.Checked)
                {
                    float contrast = trackContrast.Value / 10.0f;
                    float brightness = trackBrightness.Value / 10.0f;

                    if (contrast != 1.0f)
                    {
                        Bitmap temp = TextureImporter.AdjustContrast(processed, contrast);
                        processed.Dispose();
                        processed = temp;
                    }

                    if (brightness != 0.0f)
                    {
                        Bitmap temp = TextureImporter.AdjustBrightness(processed, brightness);
                        processed.Dispose();
                        processed = temp;
                    }

                    if (checkInvert.Checked)
                    {
                        for (int y = 0; y < processed.Height; y++)
                        {
                            for (int x = 0; x < processed.Width; x++)
                            {
                                Color pixel = processed.GetPixel(x, y);
                                processed.SetPixel(x, y, Color.FromArgb(
                                    255 - pixel.R,
                                    255 - pixel.G,
                                    255 - pixel.B
                                ));
                            }
                        }
                    }
                }

                picturePreview.Image?.Dispose();
                picturePreview.Image = processed;

                currentGeneratedTexture?.Dispose();
                currentGeneratedTexture = new Bitmap(processed);

                // Generate maps for saving
                string tempPath = Path.Combine(Path.GetTempPath(), "imported_texture.png");
                GenerateMapsFromComposite(processed, tempPath);
                lastGeneratedPath = tempPath;
                btnSave.Enabled = true;

                MessageBox.Show("Effects applied to imported texture!", "Success");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error");
            }
        }

        private void BtnMakeTileable_Click(object sender, EventArgs e)
        {
            if (importedTexture == null)
            {
                MessageBox.Show("Import a texture first!", "Error");
                return;
            }

            try
            {
                Bitmap tileable = TextureImporter.MakeTileable(importedTexture);

                importedTexture.Dispose();
                importedTexture = tileable;

                picturePreview.Image?.Dispose();
                picturePreview.Image = new Bitmap(tileable);

                currentGeneratedTexture?.Dispose();
                currentGeneratedTexture = new Bitmap(tileable);

                MessageBox.Show("Made tileable! Use 'Show 2x2' to verify.", "Success");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error");
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            // Auto-save on close if enabled
            if (checkAutoSave.Checked)
            {
                var session = CaptureCurrentSession();
                SessionManager.AutoSave(session);
            }
        }
    }
}