﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Textural
{
    public partial class LayerManagerForm : Form
    {
        public List<TextureLayer> Layers { get; private set; }
        private int selectedLayerIndex = -1;

        // Controls - add these in the designer
        // ListBox lstLayers
        // Button btnAddLayer
        // Button btnRemoveLayer
        // Button btnMoveUp
        // Button btnMoveDown
        // Button btnDuplicate
        // ComboBox comboBlendMode
        // TrackBar trackOpacity
        // Label lblOpacity, lblOpacityValue
        // CheckBox checkVisible
        // PictureBox pictureLayerPreview
        // Button btnApply
        // Button btnCancel

        public LayerManagerForm(List<TextureLayer> existingLayers = null)
        {
            InitializeComponent();

            Layers = existingLayers ?? new List<TextureLayer>();

            InitializeUI();
        }

        private void InitializeUI()
        {
            // Setup blend mode combo
            comboBlendMode.Items.AddRange(Enum.GetNames(typeof(BlendMode)));
            comboBlendMode.SelectedIndex = 0;

            // Setup events
            lstLayers.SelectedIndexChanged += LstLayers_SelectedIndexChanged;
            btnAddLayer.Click += BtnAddLayer_Click;
            btnRemoveLayer.Click += BtnRemoveLayer_Click;
            btnMoveUp.Click += BtnMoveUp_Click;
            btnMoveDown.Click += BtnMoveDown_Click;
            btnDuplicate.Click += BtnDuplicate_Click; 
            btnRename.Click += BtnRename_Click;
            txtLayerName.KeyPress += (s, e) => {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    BtnRename_Click(s, e);
                    e.Handled = true;
                }
            };

            comboBlendMode.SelectedIndexChanged += (s, e) => UpdateSelectedLayer();
            trackOpacity.Scroll += (s, e) => {
                lblOpacityValue.Text = (trackOpacity.Value / 100.0).ToString("0.00");
                UpdateSelectedLayer();
            };
            checkVisible.CheckedChanged += (s, e) => UpdateSelectedLayer();

            btnApply.Click += (s, e) => this.DialogResult = DialogResult.OK;
            btnCancel.Click += (s, e) => this.DialogResult = DialogResult.Cancel;

            RefreshLayerList();
        }

        private void RefreshLayerList()
        {
            lstLayers.Items.Clear();
            foreach (var layer in Layers)
            {
                string visibility = layer.Visible ? "👁" : "  ";
                lstLayers.Items.Add($"{visibility} {layer.Name} ({layer.BlendMode}, {(int)(layer.Opacity * 100)}%)");
            }

            if (selectedLayerIndex >= 0 && selectedLayerIndex < Layers.Count)
            {
                lstLayers.SelectedIndex = selectedLayerIndex;
            }
        }

        private void LstLayers_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedLayerIndex = lstLayers.SelectedIndex;

            if (selectedLayerIndex >= 0 && selectedLayerIndex < Layers.Count)
            {
                var layer = Layers[selectedLayerIndex];

                // Show layer name in textbox
                txtLayerName.Text = layer.Name;

                comboBlendMode.SelectedIndex = (int)layer.BlendMode;
                trackOpacity.Value = (int)(layer.Opacity * 100);
                lblOpacityValue.Text = layer.Opacity.ToString("0.00");
                checkVisible.Checked = layer.Visible;

                // Show layer preview
                if (layer.Texture != null)
                {
                    pictureLayerPreview.Image?.Dispose();
                    pictureLayerPreview.Image = new Bitmap(layer.Texture);
                }

                // Enable controls
                btnRemoveLayer.Enabled = true;
                btnDuplicate.Enabled = true;
                btnRename.Enabled = true;
                txtLayerName.Enabled = true;
                comboBlendMode.Enabled = true;
                trackOpacity.Enabled = true;
                checkVisible.Enabled = true;
            }
            else
            {
                btnRemoveLayer.Enabled = false;
                btnDuplicate.Enabled = false;
                btnRename.Enabled = false;
                txtLayerName.Enabled = false;
                txtLayerName.Text = "";
                comboBlendMode.Enabled = false;
                trackOpacity.Enabled = false;
                checkVisible.Enabled = false;
            }

            btnMoveUp.Enabled = selectedLayerIndex > 0;
            btnMoveDown.Enabled = selectedLayerIndex >= 0 && selectedLayerIndex < Layers.Count - 1;
        }

        // Add the rename handler:
        private void BtnRename_Click(object sender, EventArgs e)
        {
            if (selectedLayerIndex >= 0 && selectedLayerIndex < Layers.Count)
            {
                string newName = txtLayerName.Text.Trim();

                if (string.IsNullOrEmpty(newName))
                {
                    MessageBox.Show("Layer name cannot be empty!", "Error");
                    return;
                }

                Layers[selectedLayerIndex].Name = newName;
                RefreshLayerList();

                // Keep the same layer selected
                lstLayers.SelectedIndex = selectedLayerIndex;
            }
        }

        private void UpdateSelectedLayer()
        {
            if (selectedLayerIndex >= 0 && selectedLayerIndex < Layers.Count)
            {
                var layer = Layers[selectedLayerIndex];
                layer.BlendMode = (BlendMode)comboBlendMode.SelectedIndex;
                layer.Opacity = trackOpacity.Value / 100f;
                layer.Visible = checkVisible.Checked;

                RefreshLayerList();
            }
        }

        private void BtnAddLayer_Click(object sender, EventArgs e)
        {
            // This will be called from the main form with a new texture
            // For now, create a placeholder
            MessageBox.Show("Generate a new texture in the main window, then click 'Add as Layer'", "Info");
        }

        private void BtnRemoveLayer_Click(object sender, EventArgs e)
        {
            if (selectedLayerIndex >= 0 && selectedLayerIndex < Layers.Count)
            {
                Layers[selectedLayerIndex].Texture?.Dispose();
                Layers.RemoveAt(selectedLayerIndex);

                if (selectedLayerIndex >= Layers.Count)
                    selectedLayerIndex = Layers.Count - 1;

                RefreshLayerList();
            }
        }

        private void BtnMoveUp_Click(object sender, EventArgs e)
        {
            if (selectedLayerIndex > 0)
            {
                var temp = Layers[selectedLayerIndex];
                Layers[selectedLayerIndex] = Layers[selectedLayerIndex - 1];
                Layers[selectedLayerIndex - 1] = temp;
                selectedLayerIndex--;
                RefreshLayerList();
            }
        }

        private void BtnMoveDown_Click(object sender, EventArgs e)
        {
            if (selectedLayerIndex >= 0 && selectedLayerIndex < Layers.Count - 1)
            {
                var temp = Layers[selectedLayerIndex];
                Layers[selectedLayerIndex] = Layers[selectedLayerIndex + 1];
                Layers[selectedLayerIndex + 1] = temp;
                selectedLayerIndex++;
                RefreshLayerList();
            }
        }

        private void BtnDuplicate_Click(object sender, EventArgs e)
        {
            if (selectedLayerIndex >= 0 && selectedLayerIndex < Layers.Count)
            {
                var duplicated = Layers[selectedLayerIndex].Clone();
                Layers.Insert(selectedLayerIndex + 1, duplicated);
                selectedLayerIndex++;
                RefreshLayerList();
            }
        }

        public void AddLayer(TextureLayer layer)
        {
            Layers.Add(layer);
            selectedLayerIndex = Layers.Count - 1;
            RefreshLayerList();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            // Don't dispose layers on cancel
            if (this.DialogResult != DialogResult.OK)
            {
                // User cancelled - restore original state if needed
            }
        }
    }
}