﻿using System;
using System.Drawing;
using System.Drawing.Imaging;

namespace Textural
{
    // Blend modes for layer compositing
    public enum BlendMode
    {
        Normal,
        Multiply,
        Add,
        Screen,
        Overlay,
        Subtract
    }

    // Represents a single texture layer
    public class TextureLayer
    {
        public string Name { get; set; }
        public Bitmap Texture { get; set; }
        public float Opacity { get; set; } // 0.0 to 1.0
        public BlendMode BlendMode { get; set; }
        public bool Visible { get; set; }

        public TextureLayer(string name, Bitmap texture)
        {
            Name = name;
            Texture = texture;
            Opacity = 1.0f;
            BlendMode = BlendMode.Normal;
            Visible = true;
        }

        public TextureLayer Clone()
        {
            return new TextureLayer(Name + " Copy", new Bitmap(Texture))
            {
                Opacity = this.Opacity,
                BlendMode = this.BlendMode,
                Visible = this.Visible
            };
        }
    }

    // Manages a stack of texture layers and compositing
    public static class LayerCompositor
    {
        public static Bitmap CompositeLayer(Bitmap baseLayer, Bitmap topLayer, BlendMode mode, float opacity)
        {
            if (baseLayer == null || topLayer == null) return baseLayer;
            if (baseLayer.Width != topLayer.Width || baseLayer.Height != topLayer.Height)
                throw new ArgumentException("Layers must be the same size");

            Bitmap result = new Bitmap(baseLayer.Width, baseLayer.Height, PixelFormat.Format24bppRgb);

            for (int y = 0; y < result.Height; y++)
            {
                for (int x = 0; x < result.Width; x++)
                {
                    Color baseColor = baseLayer.GetPixel(x, y);
                    Color topColor = topLayer.GetPixel(x, y);

                    Color blended = BlendPixel(baseColor, topColor, mode, opacity);
                    result.SetPixel(x, y, blended);
                }
            }

            return result;
        }

        private static Color BlendPixel(Color baseColor, Color topColor, BlendMode mode, float opacity)
        {
            // Normalize to 0-1
            float br = baseColor.R / 255f;
            float bg = baseColor.G / 255f;
            float bb = baseColor.B / 255f;

            float tr = topColor.R / 255f;
            float tg = topColor.G / 255f;
            float tb = topColor.B / 255f;

            float r, g, b;

            switch (mode)
            {
                case BlendMode.Normal:
                    r = tr;
                    g = tg;
                    b = tb;
                    break;

                case BlendMode.Multiply:
                    r = br * tr;
                    g = bg * tg;
                    b = bb * tb;
                    break;

                case BlendMode.Add:
                    r = Math.Min(1.0f, br + tr);
                    g = Math.Min(1.0f, bg + tg);
                    b = Math.Min(1.0f, bb + tb);
                    break;

                case BlendMode.Screen:
                    r = 1.0f - (1.0f - br) * (1.0f - tr);
                    g = 1.0f - (1.0f - bg) * (1.0f - tg);
                    b = 1.0f - (1.0f - bb) * (1.0f - tb);
                    break;

                case BlendMode.Overlay:
                    r = br < 0.5f ? 2 * br * tr : 1.0f - 2 * (1.0f - br) * (1.0f - tr);
                    g = bg < 0.5f ? 2 * bg * tg : 1.0f - 2 * (1.0f - bg) * (1.0f - tg);
                    b = bb < 0.5f ? 2 * bb * tb : 1.0f - 2 * (1.0f - bb) * (1.0f - tb);
                    break;

                case BlendMode.Subtract:
                    r = Math.Max(0.0f, br - tr);
                    g = Math.Max(0.0f, bg - tg);
                    b = Math.Max(0.0f, bb - tb);
                    break;

                default:
                    r = tr;
                    g = tg;
                    b = tb;
                    break;
            }

            // Apply opacity (blend between base and blended)
            r = br + (r - br) * opacity;
            g = bg + (g - bg) * opacity;
            b = bb + (b - bb) * opacity;

            // Clamp and convert back to 0-255
            int finalR = Math.Max(0, Math.Min(255, (int)(r * 255)));
            int finalG = Math.Max(0, Math.Min(255, (int)(g * 255)));
            int finalB = Math.Max(0, Math.Min(255, (int)(b * 255)));

            return Color.FromArgb(finalR, finalG, finalB);
        }

        public static Bitmap CompositeLayers(System.Collections.Generic.List<TextureLayer> layers)
        {
            if (layers == null || layers.Count == 0) return null;

            // Find first visible layer as base
            Bitmap composite = null;
            int startIndex = 0;

            for (int i = 0; i < layers.Count; i++)
            {
                if (layers[i].Visible && layers[i].Texture != null)
                {
                    composite = new Bitmap(layers[i].Texture);
                    startIndex = i + 1;
                    break;
                }
            }

            if (composite == null) return null;

            // Blend remaining layers on top
            for (int i = startIndex; i < layers.Count; i++)
            {
                if (layers[i].Visible && layers[i].Texture != null)
                {
                    Bitmap blended = CompositeLayer(composite, layers[i].Texture, layers[i].BlendMode, layers[i].Opacity);
                    composite.Dispose();
                    composite = blended;
                }
            }

            return composite;
        }
    }
}