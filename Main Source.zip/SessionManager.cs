﻿using System;
using System.IO;
using System.Drawing;
using Newtonsoft.Json;

namespace Textural
{
    // Represents all texture generation settings
    [Serializable]
    public class TextureSession
    {
        // Basic settings
        public int Width { get; set; }
        public int Height { get; set; }
        public int NoiseType { get; set; }
        public float Scale { get; set; }
        public int Seed { get; set; }

        // FBM parameters
        public int Octaves { get; set; }
        public float Persistence { get; set; }
        public float Lacunarity { get; set; }

        // Pattern
        public int PatternType { get; set; }
        public float PatternParam { get; set; }

        // Color
        public int ColorMode { get; set; }
        public int CustomColor1R { get; set; }
        public int CustomColor1G { get; set; }
        public int CustomColor1B { get; set; }
        public int CustomColor2R { get; set; }
        public int CustomColor2G { get; set; }
        public int CustomColor2B { get; set; }
        public int CustomColor3R { get; set; }
        public int CustomColor3G { get; set; }
        public int CustomColor3B { get; set; }

        // Overlay
        public bool OverlayEnabled { get; set; }
        public int OverlayType { get; set; }
        public float OverlayParam1 { get; set; }
        public float OverlayParam2 { get; set; }
        public float OverlayIntensity { get; set; }

        // Effects
        public bool EffectsEnabled { get; set; }
        public float Contrast { get; set; }
        public float Brightness { get; set; }
        public bool Invert { get; set; }

        // Advanced
        public bool Tileable { get; set; }
        public float NormalStrength { get; set; }
        public float SpecularSmoothness { get; set; }
        public bool ExportRoughness { get; set; }
        public bool ExportMetallic { get; set; }

        // Layer system
        public bool UseLayerSystem { get; set; }

        // Metadata
        public string SessionName { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }

        public TextureSession()
        {
            // Set defaults
            Width = 512;
            Height = 512;
            NoiseType = 2; // FBM
            Scale = 100;
            Seed = 0;
            Octaves = 5;
            Persistence = 0.5f;
            Lacunarity = 2.0f;
            PatternType = 1; // Raw noise
            PatternParam = 50;
            ColorMode = 1; // Grayscale
            NormalStrength = 3.0f;
            SpecularSmoothness = 0.7f;
            CreatedDate = DateTime.Now;
            ModifiedDate = DateTime.Now;
        }
    }

    public static class SessionManager
    {
        private static string SessionFolder => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
            "Textural", "Sessions");

        static SessionManager()
        {
            // Create sessions folder if it doesn't exist
            if (!Directory.Exists(SessionFolder))
            {
                Directory.CreateDirectory(SessionFolder);
            }
        }

        public static bool SaveSession(TextureSession session, string filename)
        {
            try
            {
                session.ModifiedDate = DateTime.Now;

                string fullPath = Path.Combine(SessionFolder, filename);
                if (!fullPath.EndsWith(".json"))
                    fullPath += ".json";

                string json = JsonConvert.SerializeObject(session, Formatting.Indented);
                File.WriteAllText(fullPath, json);

                return true;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Session save error: {ex.Message}");
                return false;
            }
        }

        public static TextureSession LoadSession(string filename)
        {
            try
            {
                string fullPath = Path.Combine(SessionFolder, filename);
                if (!fullPath.EndsWith(".json"))
                    fullPath += ".json";

                if (!File.Exists(fullPath))
                    return null;

                string json = File.ReadAllText(fullPath);
                return JsonConvert.DeserializeObject<TextureSession>(json);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Session load error: {ex.Message}");
                return null;
            }
        }

        public static string[] GetAllSessions()
        {
            try
            {
                var files = Directory.GetFiles(SessionFolder, "*.json");
                for (int i = 0; i < files.Length; i++)
                {
                    files[i] = Path.GetFileNameWithoutExtension(files[i]);
                }
                return files;
            }
            catch
            {
                return new string[0];
            }
        }

        public static bool DeleteSession(string filename)
        {
            try
            {
                string fullPath = Path.Combine(SessionFolder, filename);
                if (!fullPath.EndsWith(".json"))
                    fullPath += ".json";

                if (File.Exists(fullPath))
                {
                    File.Delete(fullPath);
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        public static string GetSessionFolder()
        {
            return SessionFolder;
        }

        public static bool AutoSaveEnabled { get; set; } = true;
        private static string AutoSaveFilename = "_autosave.json";

        public static void AutoSave(TextureSession session)
        {
            if (AutoSaveEnabled)
            {
                SaveSession(session, AutoSaveFilename);
            }
        }

        public static TextureSession LoadAutoSave()
        {
            return LoadSession(AutoSaveFilename);
        }

        public static bool HasAutoSave()
        {
            string fullPath = Path.Combine(SessionFolder, AutoSaveFilename);
            return File.Exists(fullPath);
        }
    }
}