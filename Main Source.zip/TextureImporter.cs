﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace Textural
{
    public static class TextureImporter
    {
        // Import an image and optionally resize it
        public static Bitmap ImportTexture(string filePath, int targetWidth = 0, int targetHeight = 0)
        {
            try
            {
                if (!File.Exists(filePath))
                    return null;

                Bitmap original = new Bitmap(filePath);

                // If no target size specified, return original
                if (targetWidth == 0 && targetHeight == 0)
                    return original;

                // If only one dimension specified, maintain aspect ratio
                if (targetWidth == 0)
                {
                    float ratio = (float)targetHeight / original.Height;
                    targetWidth = (int)(original.Width * ratio);
                }
                else if (targetHeight == 0)
                {
                    float ratio = (float)targetWidth / original.Width;
                    targetHeight = (int)(original.Height * ratio);
                }

                // Resize
                Bitmap resized = new Bitmap(targetWidth, targetHeight);
                using (Graphics g = Graphics.FromImage(resized))
                {
                    g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    g.DrawImage(original, 0, 0, targetWidth, targetHeight);
                }

                original.Dispose();
                return resized;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Import error: {ex.Message}");
                return null;
            }
        }

        // Convert color image to grayscale heightmap
        public static Bitmap ConvertToHeightmap(Bitmap source)
        {
            Bitmap heightmap = new Bitmap(source.Width, source.Height, PixelFormat.Format24bppRgb);

            for (int y = 0; y < source.Height; y++)
            {
                for (int x = 0; x < source.Width; x++)
                {
                    Color pixel = source.GetPixel(x, y);

                    // Convert to grayscale using luminance formula
                    int gray = (int)(pixel.R * 0.299f + pixel.G * 0.587f + pixel.B * 0.114f);

                    heightmap.SetPixel(x, y, Color.FromArgb(gray, gray, gray));
                }
            }

            return heightmap;
        }

        // Generate normal map from imported image
        public static Bitmap GenerateNormalMapFromImage(Bitmap heightmap, float strength = 3.0f)
        {
            Bitmap normalMap = new Bitmap(heightmap.Width, heightmap.Height, PixelFormat.Format24bppRgb);

            for (int y = 0; y < heightmap.Height; y++)
            {
                for (int x = 0; x < heightmap.Width; x++)
                {
                    // Get neighboring pixels
                    int xLeft = Math.Max(0, x - 1);
                    int xRight = Math.Min(heightmap.Width - 1, x + 1);
                    int yUp = Math.Max(0, y - 1);
                    int yDown = Math.Min(heightmap.Height - 1, y + 1);

                    float hL = heightmap.GetPixel(xLeft, y).R / 255f;
                    float hR = heightmap.GetPixel(xRight, y).R / 255f;
                    float hU = heightmap.GetPixel(x, yUp).R / 255f;
                    float hD = heightmap.GetPixel(x, yDown).R / 255f;

                    // Calculate gradients
                    float dx = (hR - hL) * strength;
                    float dy = (hD - hU) * strength;

                    // Convert to normal
                    float nx = -dx;
                    float ny = -dy;
                    float nz = 1.0f;

                    float length = (float)Math.Sqrt(nx * nx + ny * ny + nz * nz);
                    nx /= length;
                    ny /= length;
                    nz /= length;

                    // Convert to RGB
                    int r = (int)(((nx + 1.0f) * 0.5f) * 255);
                    int g = (int)(((ny + 1.0f) * 0.5f) * 255);
                    int b = (int)(((nz + 1.0f) * 0.5f) * 255);

                    normalMap.SetPixel(x, y, Color.FromArgb(r, g, b));
                }
            }

            return normalMap;
        }

        // Apply contrast adjustment to imported image
        public static Bitmap AdjustContrast(Bitmap source, float contrast)
        {
            Bitmap result = new Bitmap(source.Width, source.Height);

            for (int y = 0; y < source.Height; y++)
            {
                for (int x = 0; x < source.Width; x++)
                {
                    Color pixel = source.GetPixel(x, y);

                    float r = (pixel.R / 255f - 0.5f) * contrast + 0.5f;
                    float g = (pixel.G / 255f - 0.5f) * contrast + 0.5f;
                    float b = (pixel.B / 255f - 0.5f) * contrast + 0.5f;

                    r = Math.Max(0, Math.Min(1, r));
                    g = Math.Max(0, Math.Min(1, g));
                    b = Math.Max(0, Math.Min(1, b));

                    result.SetPixel(x, y, Color.FromArgb(
                        (int)(r * 255),
                        (int)(g * 255),
                        (int)(b * 255)
                    ));
                }
            }

            return result;
        }

        // Apply brightness adjustment to imported image
        public static Bitmap AdjustBrightness(Bitmap source, float brightness)
        {
            Bitmap result = new Bitmap(source.Width, source.Height);

            for (int y = 0; y < source.Height; y++)
            {
                for (int x = 0; x < source.Width; x++)
                {
                    Color pixel = source.GetPixel(x, y);

                    int r = (int)Math.Max(0, Math.Min(255, pixel.R + brightness * 255));
                    int g = (int)Math.Max(0, Math.Min(255, pixel.G + brightness * 255));
                    int b = (int)Math.Max(0, Math.Min(255, pixel.B + brightness * 255));

                    result.SetPixel(x, y, Color.FromArgb(r, g, b));
                }
            }

            return result;
        }

        // Make texture tileable using mirror/blend technique
        public static Bitmap MakeTileable(Bitmap source)
        {
            Bitmap tileable = new Bitmap(source.Width, source.Height);

            for (int y = 0; y < source.Height; y++)
            {
                for (int x = 0; x < source.Width; x++)
                {
                    // Get 4 mirrored samples
                    Color c1 = source.GetPixel(x, y);
                    Color c2 = source.GetPixel(source.Width - 1 - x, y);
                    Color c3 = source.GetPixel(x, source.Height - 1 - y);
                    Color c4 = source.GetPixel(source.Width - 1 - x, source.Height - 1 - y);

                    // Blend weights based on position
                    float wx = (float)x / source.Width;
                    float wy = (float)y / source.Height;

                    // Linear blend
                    float r = c1.R * (1 - wx) * (1 - wy) +
                             c2.R * wx * (1 - wy) +
                             c3.R * (1 - wx) * wy +
                             c4.R * wx * wy;

                    float g = c1.G * (1 - wx) * (1 - wy) +
                             c2.G * wx * (1 - wy) +
                             c3.G * (1 - wx) * wy +
                             c4.G * wx * wy;

                    float b = c1.B * (1 - wx) * (1 - wy) +
                             c2.B * wx * (1 - wy) +
                             c3.B * (1 - wx) * wy +
                             c4.B * wx * wy;

                    tileable.SetPixel(x, y, Color.FromArgb(
                        (int)Math.Max(0, Math.Min(255, r)),
                        (int)Math.Max(0, Math.Min(255, g)),
                        (int)Math.Max(0, Math.Min(255, b))
                    ));
                }
            }

            return tileable;
        }

        // Normalize imported texture (stretch values to full 0-255 range)
        public static Bitmap Normalize(Bitmap source)
        {
            // Find min/max values
            int minR = 255, minG = 255, minB = 255;
            int maxR = 0, maxG = 0, maxB = 0;

            for (int y = 0; y < source.Height; y++)
            {
                for (int x = 0; x < source.Width; x++)
                {
                    Color pixel = source.GetPixel(x, y);
                    minR = Math.Min(minR, pixel.R);
                    minG = Math.Min(minG, pixel.G);
                    minB = Math.Min(minB, pixel.B);
                    maxR = Math.Max(maxR, pixel.R);
                    maxG = Math.Max(maxG, pixel.G);
                    maxB = Math.Max(maxB, pixel.B);
                }
            }

            // Normalize
            Bitmap result = new Bitmap(source.Width, source.Height);

            for (int y = 0; y < source.Height; y++)
            {
                for (int x = 0; x < source.Width; x++)
                {
                    Color pixel = source.GetPixel(x, y);

                    float r = (pixel.R - minR) / (float)(maxR - minR);
                    float g = (pixel.G - minG) / (float)(maxG - minG);
                    float b = (pixel.B - minB) / (float)(maxB - minB);

                    result.SetPixel(x, y, Color.FromArgb(
                        (int)(r * 255),
                        (int)(g * 255),
                        (int)(b * 255)
                    ));
                }
            }

            return result;
        }

        // Get supported file formats
        public static string GetSupportedFormats()
        {
            return "Image Files|*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff;*.gif|" +
                   "PNG Files|*.png|" +
                   "JPEG Files|*.jpg;*.jpeg|" +
                   "All Files|*.*";
        }
    }
}