﻿namespace Textural
{
    partial class LayerManagerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstLayers = new System.Windows.Forms.ListBox();
            this.btnAddLayer = new System.Windows.Forms.Button();
            this.btnRemoveLayer = new System.Windows.Forms.Button();
            this.btnMoveUp = new System.Windows.Forms.Button();
            this.btnMoveDown = new System.Windows.Forms.Button();
            this.btnDuplicate = new System.Windows.Forms.Button();
            this.comboBlendMode = new System.Windows.Forms.ComboBox();
            this.trackOpacity = new System.Windows.Forms.TrackBar();
            this.lblOpacity = new System.Windows.Forms.Label();
            this.lblOpacityValue = new System.Windows.Forms.Label();
            this.checkVisible = new System.Windows.Forms.CheckBox();
            this.pictureLayerPreview = new System.Windows.Forms.PictureBox();
            this.btnApply = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtLayerName = new System.Windows.Forms.TextBox();
            this.btnRename = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.trackOpacity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureLayerPreview)).BeginInit();
            this.SuspendLayout();
            // 
            // lstLayers
            // 
            this.lstLayers.FormattingEnabled = true;
            this.lstLayers.ItemHeight = 16;
            this.lstLayers.Location = new System.Drawing.Point(284, 4);
            this.lstLayers.Name = "lstLayers";
            this.lstLayers.Size = new System.Drawing.Size(254, 212);
            this.lstLayers.TabIndex = 0;
            // 
            // btnAddLayer
            // 
            this.btnAddLayer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.btnAddLayer.Location = new System.Drawing.Point(630, 34);
            this.btnAddLayer.Name = "btnAddLayer";
            this.btnAddLayer.Size = new System.Drawing.Size(167, 50);
            this.btnAddLayer.TabIndex = 1;
            this.btnAddLayer.Text = "Add Layer";
            this.btnAddLayer.UseVisualStyleBackColor = false;
            // 
            // btnRemoveLayer
            // 
            this.btnRemoveLayer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.btnRemoveLayer.Location = new System.Drawing.Point(630, 90);
            this.btnRemoveLayer.Name = "btnRemoveLayer";
            this.btnRemoveLayer.Size = new System.Drawing.Size(167, 50);
            this.btnRemoveLayer.TabIndex = 2;
            this.btnRemoveLayer.Text = "Remove Layer";
            this.btnRemoveLayer.UseVisualStyleBackColor = false;
            // 
            // btnMoveUp
            // 
            this.btnMoveUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.btnMoveUp.Location = new System.Drawing.Point(544, 4);
            this.btnMoveUp.Name = "btnMoveUp";
            this.btnMoveUp.Size = new System.Drawing.Size(80, 80);
            this.btnMoveUp.TabIndex = 3;
            this.btnMoveUp.Text = "Move Up";
            this.btnMoveUp.UseVisualStyleBackColor = false;
            // 
            // btnMoveDown
            // 
            this.btnMoveDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.btnMoveDown.Location = new System.Drawing.Point(544, 90);
            this.btnMoveDown.Name = "btnMoveDown";
            this.btnMoveDown.Size = new System.Drawing.Size(80, 80);
            this.btnMoveDown.TabIndex = 4;
            this.btnMoveDown.Text = "Move Down";
            this.btnMoveDown.UseVisualStyleBackColor = false;
            // 
            // btnDuplicate
            // 
            this.btnDuplicate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.btnDuplicate.Location = new System.Drawing.Point(630, 146);
            this.btnDuplicate.Name = "btnDuplicate";
            this.btnDuplicate.Size = new System.Drawing.Size(167, 50);
            this.btnDuplicate.TabIndex = 5;
            this.btnDuplicate.Text = "Duplicate";
            this.btnDuplicate.UseVisualStyleBackColor = false;
            // 
            // comboBlendMode
            // 
            this.comboBlendMode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.comboBlendMode.ForeColor = System.Drawing.Color.White;
            this.comboBlendMode.FormattingEnabled = true;
            this.comboBlendMode.Location = new System.Drawing.Point(630, 4);
            this.comboBlendMode.Name = "comboBlendMode";
            this.comboBlendMode.Size = new System.Drawing.Size(167, 24);
            this.comboBlendMode.TabIndex = 6;
            // 
            // trackOpacity
            // 
            this.trackOpacity.AutoSize = false;
            this.trackOpacity.Location = new System.Drawing.Point(342, 285);
            this.trackOpacity.Maximum = 100;
            this.trackOpacity.Name = "trackOpacity";
            this.trackOpacity.Size = new System.Drawing.Size(241, 45);
            this.trackOpacity.TabIndex = 7;
            this.trackOpacity.Value = 100;
            // 
            // lblOpacity
            // 
            this.lblOpacity.AutoSize = true;
            this.lblOpacity.Location = new System.Drawing.Point(280, 289);
            this.lblOpacity.Name = "lblOpacity";
            this.lblOpacity.Size = new System.Drawing.Size(56, 16);
            this.lblOpacity.TabIndex = 8;
            this.lblOpacity.Text = "Opacity:";
            // 
            // lblOpacityValue
            // 
            this.lblOpacityValue.AutoSize = true;
            this.lblOpacityValue.Location = new System.Drawing.Point(589, 289);
            this.lblOpacityValue.Name = "lblOpacityValue";
            this.lblOpacityValue.Size = new System.Drawing.Size(31, 16);
            this.lblOpacityValue.TabIndex = 9;
            this.lblOpacityValue.Text = "1.00";
            // 
            // checkVisible
            // 
            this.checkVisible.AutoSize = true;
            this.checkVisible.Location = new System.Drawing.Point(672, 285);
            this.checkVisible.Name = "checkVisible";
            this.checkVisible.Size = new System.Drawing.Size(70, 20);
            this.checkVisible.TabIndex = 10;
            this.checkVisible.Text = "Visible";
            this.checkVisible.UseVisualStyleBackColor = true;
            // 
            // pictureLayerPreview
            // 
            this.pictureLayerPreview.Location = new System.Drawing.Point(4, 4);
            this.pictureLayerPreview.Name = "pictureLayerPreview";
            this.pictureLayerPreview.Size = new System.Drawing.Size(275, 275);
            this.pictureLayerPreview.TabIndex = 11;
            this.pictureLayerPreview.TabStop = false;
            // 
            // btnApply
            // 
            this.btnApply.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.btnApply.Location = new System.Drawing.Point(403, 333);
            this.btnApply.Name = "btnApply";
            this.btnApply.Size = new System.Drawing.Size(120, 60);
            this.btnApply.TabIndex = 12;
            this.btnApply.Text = "Apply";
            this.btnApply.UseVisualStyleBackColor = false;
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.btnCancel.Location = new System.Drawing.Point(548, 332);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(120, 60);
            this.btnCancel.TabIndex = 13;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            // 
            // txtLayerName
            // 
            this.txtLayerName.Location = new System.Drawing.Point(283, 235);
            this.txtLayerName.Name = "txtLayerName";
            this.txtLayerName.Size = new System.Drawing.Size(341, 22);
            this.txtLayerName.TabIndex = 14;
            // 
            // btnRename
            // 
            this.btnRename.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.btnRename.Location = new System.Drawing.Point(630, 221);
            this.btnRename.Name = "btnRename";
            this.btnRename.Size = new System.Drawing.Size(167, 50);
            this.btnRename.TabIndex = 15;
            this.btnRename.Text = "Rename";
            this.btnRename.UseVisualStyleBackColor = false;
            // 
            // LayerManagerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnRename);
            this.Controls.Add(this.txtLayerName);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnApply);
            this.Controls.Add(this.pictureLayerPreview);
            this.Controls.Add(this.checkVisible);
            this.Controls.Add(this.lblOpacityValue);
            this.Controls.Add(this.lblOpacity);
            this.Controls.Add(this.trackOpacity);
            this.Controls.Add(this.comboBlendMode);
            this.Controls.Add(this.btnDuplicate);
            this.Controls.Add(this.btnMoveDown);
            this.Controls.Add(this.btnMoveUp);
            this.Controls.Add(this.btnRemoveLayer);
            this.Controls.Add(this.btnAddLayer);
            this.Controls.Add(this.lstLayers);
            this.ForeColor = System.Drawing.Color.White;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "LayerManagerForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Layer Manager";
            ((System.ComponentModel.ISupportInitialize)(this.trackOpacity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureLayerPreview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstLayers;
        private System.Windows.Forms.Button btnAddLayer;
        private System.Windows.Forms.Button btnRemoveLayer;
        private System.Windows.Forms.Button btnMoveUp;
        private System.Windows.Forms.Button btnMoveDown;
        private System.Windows.Forms.Button btnDuplicate;
        private System.Windows.Forms.ComboBox comboBlendMode;
        private System.Windows.Forms.TrackBar trackOpacity;
        private System.Windows.Forms.Label lblOpacity;
        private System.Windows.Forms.Label lblOpacityValue;
        private System.Windows.Forms.CheckBox checkVisible;
        private System.Windows.Forms.PictureBox pictureLayerPreview;
        private System.Windows.Forms.Button btnApply;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox txtLayerName;
        private System.Windows.Forms.Button btnRename;
    }
}