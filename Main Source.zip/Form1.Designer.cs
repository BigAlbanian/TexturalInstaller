﻿namespace TextureGeneratorGUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblLacunarityValue = new System.Windows.Forms.Label();
            this.trackLacunarity = new System.Windows.Forms.TrackBar();
            this.label8 = new System.Windows.Forms.Label();
            this.lblPersistenceValue = new System.Windows.Forms.Label();
            this.trackPersistence = new System.Windows.Forms.TrackBar();
            this.label6 = new System.Windows.Forms.Label();
            this.lblOctavesValue = new System.Windows.Forms.Label();
            this.trackOctaves = new System.Windows.Forms.TrackBar();
            this.label5 = new System.Windows.Forms.Label();
            this.numScale = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.numHeight = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.numWidth = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.comboNoiseType = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnRandomSeed = new System.Windows.Forms.Button();
            this.numSeed = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.lblPatternParamValue = new System.Windows.Forms.Label();
            this.trackPatternParam = new System.Windows.Forms.TrackBar();
            this.label9 = new System.Windows.Forms.Label();
            this.comboPattern = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnColor3 = new System.Windows.Forms.Button();
            this.lblColor3 = new System.Windows.Forms.Label();
            this.btnColor2 = new System.Windows.Forms.Button();
            this.lblColor2 = new System.Windows.Forms.Label();
            this.btnColor1 = new System.Windows.Forms.Button();
            this.lblColor1 = new System.Windows.Forms.Label();
            this.comboColor = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.checkPlankUniqueGrain = new System.Windows.Forms.CheckBox();
            this.lblOverlayParam2Value = new System.Windows.Forms.Label();
            this.trackOverlayParam2 = new System.Windows.Forms.TrackBar();
            this.label19 = new System.Windows.Forms.Label();
            this.lblOverlayParam1Value = new System.Windows.Forms.Label();
            this.trackOverlayParam1 = new System.Windows.Forms.TrackBar();
            this.label17 = new System.Windows.Forms.Label();
            this.lblOverlayIntensityValue = new System.Windows.Forms.Label();
            this.trackOverlayIntensity = new System.Windows.Forms.TrackBar();
            this.label13 = new System.Windows.Forms.Label();
            this.comboOverlay = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.checkEnableOverlay = new System.Windows.Forms.CheckBox();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.picturePreview = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.checkInvert = new System.Windows.Forms.CheckBox();
            this.lblBrightnessValue = new System.Windows.Forms.Label();
            this.trackBrightness = new System.Windows.Forms.TrackBar();
            this.label16 = new System.Windows.Forms.Label();
            this.lblContrastValue = new System.Windows.Forms.Label();
            this.trackContrast = new System.Windows.Forms.TrackBar();
            this.label15 = new System.Windows.Forms.Label();
            this.checkEnableEffects = new System.Windows.Forms.CheckBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.checkTileable = new System.Windows.Forms.CheckBox();
            this.checkShow2x2 = new System.Windows.Forms.CheckBox();
            this.lblNormalStrength = new System.Windows.Forms.Label();
            this.lblNormalStrengthValue = new System.Windows.Forms.Label();
            this.trackNormalStrength = new System.Windows.Forms.TrackBar();
            this.trackSpecSmooth = new System.Windows.Forms.TrackBar();
            this.lblSpecSmoothValue = new System.Windows.Forms.Label();
            this.lblSpecSmooth = new System.Windows.Forms.Label();
            this.checkExportRoughness = new System.Windows.Forms.CheckBox();
            this.checkExportMetallic = new System.Windows.Forms.CheckBox();
            this.checkUseLayerSystem = new System.Windows.Forms.CheckBox();
            this.btnAddAsLayer = new System.Windows.Forms.Button();
            this.btnOpenLayerManager = new System.Windows.Forms.Button();
            this.btnSaveSession = new System.Windows.Forms.Button();
            this.btnLoadSession = new System.Windows.Forms.Button();
            this.checkAutoSave = new System.Windows.Forms.CheckBox();
            this.btnImportTexture = new System.Windows.Forms.Button();
            this.btnApplyToImported = new System.Windows.Forms.Button();
            this.btnMakeTileable = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackLacunarity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackPersistence)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackOctaves)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numScale)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numHeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numWidth)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackPatternParam)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackOverlayParam2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackOverlayParam1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackOverlayIntensity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picturePreview)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBrightness)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackContrast)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackNormalStrength)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackSpecSmooth)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.lblLacunarityValue);
            this.groupBox1.Controls.Add(this.trackLacunarity);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.lblPersistenceValue);
            this.groupBox1.Controls.Add(this.trackPersistence);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.lblOctavesValue);
            this.groupBox1.Controls.Add(this.trackOctaves);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.numScale);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.numHeight);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.numWidth);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.comboNoiseType);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(20, 20);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(450, 270);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // lblLacunarityValue
            // 
            this.lblLacunarityValue.ForeColor = System.Drawing.Color.White;
            this.lblLacunarityValue.Location = new System.Drawing.Point(310, 222);
            this.lblLacunarityValue.Name = "lblLacunarityValue";
            this.lblLacunarityValue.Size = new System.Drawing.Size(40, 20);
            this.lblLacunarityValue.TabIndex = 14;
            this.lblLacunarityValue.Text = "2.0";
            // 
            // trackLacunarity
            // 
            this.trackLacunarity.AutoSize = false;
            this.trackLacunarity.Location = new System.Drawing.Point(100, 215);
            this.trackLacunarity.Maximum = 40;
            this.trackLacunarity.Minimum = 15;
            this.trackLacunarity.Name = "trackLacunarity";
            this.trackLacunarity.Size = new System.Drawing.Size(200, 45);
            this.trackLacunarity.TabIndex = 13;
            this.trackLacunarity.TickFrequency = 5;
            this.trackLacunarity.Value = 20;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(10, 220);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 16);
            this.label8.TabIndex = 12;
            this.label8.Text = "Lacunarity:\n";
            // 
            // lblPersistenceValue
            // 
            this.lblPersistenceValue.ForeColor = System.Drawing.Color.White;
            this.lblPersistenceValue.Location = new System.Drawing.Point(310, 182);
            this.lblPersistenceValue.Name = "lblPersistenceValue";
            this.lblPersistenceValue.Size = new System.Drawing.Size(40, 20);
            this.lblPersistenceValue.TabIndex = 11;
            this.lblPersistenceValue.Text = "0.5";
            // 
            // trackPersistence
            // 
            this.trackPersistence.AutoSize = false;
            this.trackPersistence.Location = new System.Drawing.Point(100, 175);
            this.trackPersistence.Maximum = 9;
            this.trackPersistence.Minimum = 1;
            this.trackPersistence.Name = "trackPersistence";
            this.trackPersistence.Size = new System.Drawing.Size(200, 45);
            this.trackPersistence.TabIndex = 10;
            this.trackPersistence.Value = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(10, 175);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 16);
            this.label6.TabIndex = 1;
            this.label6.Text = "Persistence:\n";
            // 
            // lblOctavesValue
            // 
            this.lblOctavesValue.ForeColor = System.Drawing.Color.White;
            this.lblOctavesValue.Location = new System.Drawing.Point(310, 150);
            this.lblOctavesValue.Name = "lblOctavesValue";
            this.lblOctavesValue.Size = new System.Drawing.Size(30, 20);
            this.lblOctavesValue.TabIndex = 9;
            this.lblOctavesValue.Text = "5\n";
            this.lblOctavesValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // trackOctaves
            // 
            this.trackOctaves.AutoSize = false;
            this.trackOctaves.Location = new System.Drawing.Point(100, 143);
            this.trackOctaves.Maximum = 8;
            this.trackOctaves.Minimum = 1;
            this.trackOctaves.Name = "trackOctaves";
            this.trackOctaves.Size = new System.Drawing.Size(200, 45);
            this.trackOctaves.TabIndex = 8;
            this.trackOctaves.Value = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(10, 145);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 16);
            this.label5.TabIndex = 7;
            this.label5.Text = "Octaves:\n";
            // 
            // numScale
            // 
            this.numScale.DecimalPlaces = 1;
            this.numScale.Location = new System.Drawing.Point(100, 113);
            this.numScale.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.numScale.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numScale.Name = "numScale";
            this.numScale.Size = new System.Drawing.Size(100, 22);
            this.numScale.TabIndex = 6;
            this.numScale.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(10, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "Scale:\n";
            // 
            // numHeight
            // 
            this.numHeight.Location = new System.Drawing.Point(100, 83);
            this.numHeight.Maximum = new decimal(new int[] {
            4096,
            0,
            0,
            0});
            this.numHeight.Minimum = new decimal(new int[] {
            64,
            0,
            0,
            0});
            this.numHeight.Name = "numHeight";
            this.numHeight.Size = new System.Drawing.Size(100, 22);
            this.numHeight.TabIndex = 4;
            this.numHeight.Value = new decimal(new int[] {
            512,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(10, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Height:\n";
            // 
            // numWidth
            // 
            this.numWidth.Location = new System.Drawing.Point(100, 53);
            this.numWidth.Maximum = new decimal(new int[] {
            4096,
            0,
            0,
            0});
            this.numWidth.Minimum = new decimal(new int[] {
            64,
            0,
            0,
            0});
            this.numWidth.Name = "numWidth";
            this.numWidth.Size = new System.Drawing.Size(100, 22);
            this.numWidth.TabIndex = 2;
            this.numWidth.Value = new decimal(new int[] {
            512,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(10, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Width:";
            // 
            // comboNoiseType
            // 
            this.comboNoiseType.FormattingEnabled = true;
            this.comboNoiseType.Items.AddRange(new object[] {
            "Perlin Noise",
            "Fractal Brownian Motion (fBm)"});
            this.comboNoiseType.Location = new System.Drawing.Point(100, 22);
            this.comboNoiseType.Name = "comboNoiseType";
            this.comboNoiseType.Size = new System.Drawing.Size(240, 24);
            this.comboNoiseType.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(10, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Noise Type:\n";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.btnRandomSeed);
            this.groupBox2.Controls.Add(this.numSeed);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.lblPatternParamValue);
            this.groupBox2.Controls.Add(this.trackPatternParam);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.comboPattern);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Location = new System.Drawing.Point(20, 306);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(450, 140);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            // 
            // btnRandomSeed
            // 
            this.btnRandomSeed.ForeColor = System.Drawing.Color.Black;
            this.btnRandomSeed.Location = new System.Drawing.Point(230, 102);
            this.btnRandomSeed.Name = "btnRandomSeed";
            this.btnRandomSeed.Size = new System.Drawing.Size(70, 23);
            this.btnRandomSeed.TabIndex = 7;
            this.btnRandomSeed.Text = "Random";
            this.btnRandomSeed.UseVisualStyleBackColor = true;
            // 
            // numSeed
            // 
            this.numSeed.Location = new System.Drawing.Point(100, 103);
            this.numSeed.Maximum = new decimal(new int[] {
            -469762049,
            -590869294,
            5421010,
            0});
            this.numSeed.Name = "numSeed";
            this.numSeed.Size = new System.Drawing.Size(120, 22);
            this.numSeed.TabIndex = 6;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(10, 105);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 16);
            this.label10.TabIndex = 5;
            this.label10.Text = "Seed:\n";
            // 
            // lblPatternParamValue
            // 
            this.lblPatternParamValue.ForeColor = System.Drawing.Color.White;
            this.lblPatternParamValue.Location = new System.Drawing.Point(310, 62);
            this.lblPatternParamValue.Name = "lblPatternParamValue";
            this.lblPatternParamValue.Size = new System.Drawing.Size(40, 20);
            this.lblPatternParamValue.TabIndex = 4;
            this.lblPatternParamValue.Text = "50";
            // 
            // trackPatternParam
            // 
            this.trackPatternParam.AutoSize = false;
            this.trackPatternParam.Location = new System.Drawing.Point(100, 55);
            this.trackPatternParam.Maximum = 150;
            this.trackPatternParam.Minimum = 20;
            this.trackPatternParam.Name = "trackPatternParam";
            this.trackPatternParam.Size = new System.Drawing.Size(200, 45);
            this.trackPatternParam.TabIndex = 3;
            this.trackPatternParam.TickFrequency = 10;
            this.trackPatternParam.Value = 50;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(10, 60);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 16);
            this.label9.TabIndex = 2;
            this.label9.Text = "Pattern Scale:\n";
            // 
            // comboPattern
            // 
            this.comboPattern.FormattingEnabled = true;
            this.comboPattern.Items.AddRange(new object[] {
            "Raw Noise",
            "Wood (Rings/Top View)",
            "Marble",
            "Clouds",
            "Stone/Rock",
            "Voronoi/Cells",
            "Brushed Metal",
            "Scales",
            "Checkerboard",
            "Wood Grain (Side View)",
            "Diamond Plate",
            "Leather"});
            this.comboPattern.Location = new System.Drawing.Point(100, 22);
            this.comboPattern.Name = "comboPattern";
            this.comboPattern.Size = new System.Drawing.Size(240, 24);
            this.comboPattern.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(10, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 16);
            this.label7.TabIndex = 0;
            this.label7.Text = "Pattern Type:\n";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.btnColor3);
            this.groupBox3.Controls.Add(this.lblColor3);
            this.groupBox3.Controls.Add(this.btnColor2);
            this.groupBox3.Controls.Add(this.lblColor2);
            this.groupBox3.Controls.Add(this.btnColor1);
            this.groupBox3.Controls.Add(this.lblColor1);
            this.groupBox3.Controls.Add(this.comboColor);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Location = new System.Drawing.Point(20, 456);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(450, 100);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            // 
            // btnColor3
            // 
            this.btnColor3.BackColor = System.Drawing.Color.BurlyWood;
            this.btnColor3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColor3.Location = new System.Drawing.Point(365, 52);
            this.btnColor3.Name = "btnColor3";
            this.btnColor3.Size = new System.Drawing.Size(80, 25);
            this.btnColor3.TabIndex = 7;
            this.btnColor3.UseVisualStyleBackColor = false;
            this.btnColor3.Visible = false;
            // 
            // lblColor3
            // 
            this.lblColor3.AutoSize = true;
            this.lblColor3.ForeColor = System.Drawing.Color.White;
            this.lblColor3.Location = new System.Drawing.Point(305, 55);
            this.lblColor3.Name = "lblColor3";
            this.lblColor3.Size = new System.Drawing.Size(52, 16);
            this.lblColor3.TabIndex = 6;
            this.lblColor3.Text = "Color 3:\n";
            this.lblColor3.Visible = false;
            // 
            // btnColor2
            // 
            this.btnColor2.BackColor = System.Drawing.Color.Peru;
            this.btnColor2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColor2.Location = new System.Drawing.Point(220, 52);
            this.btnColor2.Name = "btnColor2";
            this.btnColor2.Size = new System.Drawing.Size(80, 25);
            this.btnColor2.TabIndex = 5;
            this.btnColor2.UseVisualStyleBackColor = false;
            this.btnColor2.Visible = false;
            // 
            // lblColor2
            // 
            this.lblColor2.AutoSize = true;
            this.lblColor2.ForeColor = System.Drawing.Color.White;
            this.lblColor2.Location = new System.Drawing.Point(160, 55);
            this.lblColor2.Name = "lblColor2";
            this.lblColor2.Size = new System.Drawing.Size(52, 16);
            this.lblColor2.TabIndex = 4;
            this.lblColor2.Text = "Color 2:\n";
            this.lblColor2.Visible = false;
            // 
            // btnColor1
            // 
            this.btnColor1.BackColor = System.Drawing.Color.Brown;
            this.btnColor1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnColor1.Location = new System.Drawing.Point(70, 52);
            this.btnColor1.Name = "btnColor1";
            this.btnColor1.Size = new System.Drawing.Size(80, 25);
            this.btnColor1.TabIndex = 3;
            this.btnColor1.UseVisualStyleBackColor = false;
            this.btnColor1.Visible = false;
            // 
            // lblColor1
            // 
            this.lblColor1.AutoSize = true;
            this.lblColor1.ForeColor = System.Drawing.Color.White;
            this.lblColor1.Location = new System.Drawing.Point(10, 55);
            this.lblColor1.Name = "lblColor1";
            this.lblColor1.Size = new System.Drawing.Size(52, 16);
            this.lblColor1.TabIndex = 2;
            this.lblColor1.Text = "Color 1:";
            this.lblColor1.Visible = false;
            // 
            // comboColor
            // 
            this.comboColor.FormattingEnabled = true;
            this.comboColor.Items.AddRange(new object[] {
            "Grayscale",
            "Wood (brown tones)",
            "Marble (white/gray)",
            "Stone (gray tones)",
            "Green Terrain",
            "Blue Water",
            "Fire/Lava",
            "Custom Gradient"});
            this.comboColor.Location = new System.Drawing.Point(100, 22);
            this.comboColor.Name = "comboColor";
            this.comboColor.Size = new System.Drawing.Size(240, 24);
            this.comboColor.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(10, 25);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(80, 16);
            this.label11.TabIndex = 0;
            this.label11.Text = "Color Mode:\n";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.checkPlankUniqueGrain);
            this.groupBox4.Controls.Add(this.lblOverlayParam2Value);
            this.groupBox4.Controls.Add(this.trackOverlayParam2);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.lblOverlayParam1Value);
            this.groupBox4.Controls.Add(this.trackOverlayParam1);
            this.groupBox4.Controls.Add(this.label17);
            this.groupBox4.Controls.Add(this.lblOverlayIntensityValue);
            this.groupBox4.Controls.Add(this.trackOverlayIntensity);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.comboOverlay);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.checkEnableOverlay);
            this.groupBox4.Location = new System.Drawing.Point(20, 581);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(450, 201);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "\n";
            // 
            // checkPlankUniqueGrain
            // 
            this.checkPlankUniqueGrain.AutoSize = true;
            this.checkPlankUniqueGrain.Enabled = false;
            this.checkPlankUniqueGrain.Location = new System.Drawing.Point(138, 25);
            this.checkPlankUniqueGrain.Name = "checkPlankUniqueGrain";
            this.checkPlankUniqueGrain.Size = new System.Drawing.Size(168, 20);
            this.checkPlankUniqueGrain.TabIndex = 12;
            this.checkPlankUniqueGrain.Text = "Unique Grain Per Plank";
            this.checkPlankUniqueGrain.UseVisualStyleBackColor = true;
            // 
            // lblOverlayParam2Value
            // 
            this.lblOverlayParam2Value.ForeColor = System.Drawing.Color.White;
            this.lblOverlayParam2Value.Location = new System.Drawing.Point(359, 152);
            this.lblOverlayParam2Value.Name = "lblOverlayParam2Value";
            this.lblOverlayParam2Value.Size = new System.Drawing.Size(40, 20);
            this.lblOverlayParam2Value.TabIndex = 11;
            this.lblOverlayParam2Value.Text = "50";
            // 
            // trackOverlayParam2
            // 
            this.trackOverlayParam2.AutoSize = false;
            this.trackOverlayParam2.Enabled = false;
            this.trackOverlayParam2.Location = new System.Drawing.Point(199, 145);
            this.trackOverlayParam2.Maximum = 100;
            this.trackOverlayParam2.Minimum = 25;
            this.trackOverlayParam2.Name = "trackOverlayParam2";
            this.trackOverlayParam2.Size = new System.Drawing.Size(150, 45);
            this.trackOverlayParam2.TabIndex = 10;
            this.trackOverlayParam2.Value = 50;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(10, 145);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(131, 16);
            this.label19.TabIndex = 9;
            this.label19.Text = "Brick Height (if brick):";
            // 
            // lblOverlayParam1Value
            // 
            this.lblOverlayParam1Value.ForeColor = System.Drawing.Color.White;
            this.lblOverlayParam1Value.Location = new System.Drawing.Point(359, 117);
            this.lblOverlayParam1Value.Name = "lblOverlayParam1Value";
            this.lblOverlayParam1Value.Size = new System.Drawing.Size(40, 20);
            this.lblOverlayParam1Value.TabIndex = 8;
            this.lblOverlayParam1Value.Text = "80";
            // 
            // trackOverlayParam1
            // 
            this.trackOverlayParam1.AutoSize = false;
            this.trackOverlayParam1.Enabled = false;
            this.trackOverlayParam1.Location = new System.Drawing.Point(199, 110);
            this.trackOverlayParam1.Maximum = 200;
            this.trackOverlayParam1.Minimum = 30;
            this.trackOverlayParam1.Name = "trackOverlayParam1";
            this.trackOverlayParam1.Size = new System.Drawing.Size(150, 45);
            this.trackOverlayParam1.TabIndex = 7;
            this.trackOverlayParam1.TickFrequency = 10;
            this.trackOverlayParam1.Value = 80;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(8, 116);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(147, 16);
            this.label17.TabIndex = 6;
            this.label17.Text = "Vein/Brick/Plank Scale:";
            // 
            // lblOverlayIntensityValue
            // 
            this.lblOverlayIntensityValue.ForeColor = System.Drawing.Color.White;
            this.lblOverlayIntensityValue.Location = new System.Drawing.Point(359, 87);
            this.lblOverlayIntensityValue.Name = "lblOverlayIntensityValue";
            this.lblOverlayIntensityValue.Size = new System.Drawing.Size(40, 20);
            this.lblOverlayIntensityValue.TabIndex = 5;
            this.lblOverlayIntensityValue.Text = "0.5";
            // 
            // trackOverlayIntensity
            // 
            this.trackOverlayIntensity.AutoSize = false;
            this.trackOverlayIntensity.Enabled = false;
            this.trackOverlayIntensity.Location = new System.Drawing.Point(149, 80);
            this.trackOverlayIntensity.Minimum = 1;
            this.trackOverlayIntensity.Name = "trackOverlayIntensity";
            this.trackOverlayIntensity.Size = new System.Drawing.Size(200, 45);
            this.trackOverlayIntensity.TabIndex = 4;
            this.trackOverlayIntensity.Value = 5;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(10, 85);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(58, 16);
            this.label13.TabIndex = 3;
            this.label13.Text = "Intensity:\n";
            // 
            // comboOverlay
            // 
            this.comboOverlay.Enabled = false;
            this.comboOverlay.FormattingEnabled = true;
            this.comboOverlay.Items.AddRange(new object[] {
            "Marble Veins",
            "Brick Pattern",
            "Wood Planks"});
            this.comboOverlay.Location = new System.Drawing.Point(100, 52);
            this.comboOverlay.Name = "comboOverlay";
            this.comboOverlay.Size = new System.Drawing.Size(240, 24);
            this.comboOverlay.TabIndex = 2;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(10, 55);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(92, 16);
            this.label12.TabIndex = 1;
            this.label12.Text = "Overlay Type:";
            // 
            // checkEnableOverlay
            // 
            this.checkEnableOverlay.AutoSize = true;
            this.checkEnableOverlay.Location = new System.Drawing.Point(10, 25);
            this.checkEnableOverlay.Name = "checkEnableOverlay";
            this.checkEnableOverlay.Size = new System.Drawing.Size(122, 20);
            this.checkEnableOverlay.TabIndex = 0;
            this.checkEnableOverlay.Text = "Enable Overlay";
            this.checkEnableOverlay.UseVisualStyleBackColor = true;
            // 
            // btnGenerate
            // 
            this.btnGenerate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.btnGenerate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnGenerate.ForeColor = System.Drawing.Color.White;
            this.btnGenerate.Location = new System.Drawing.Point(1241, 612);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(360, 40);
            this.btnGenerate.TabIndex = 6;
            this.btnGenerate.Text = "Generate Texture";
            this.btnGenerate.UseVisualStyleBackColor = false;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.btnSave.Enabled = false;
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(1241, 658);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(360, 30);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Save As...\n";
            this.btnSave.UseVisualStyleBackColor = false;
            // 
            // picturePreview
            // 
            this.picturePreview.InitialImage = global::Textural.Properties.Resources.texturaliconblacknwhite;
            this.picturePreview.Location = new System.Drawing.Point(496, 20);
            this.picturePreview.Name = "picturePreview";
            this.picturePreview.Size = new System.Drawing.Size(720, 664);
            this.picturePreview.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picturePreview.TabIndex = 8;
            this.picturePreview.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(496, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(81, 20);
            this.label14.TabIndex = 9;
            this.label14.Text = "Preview:\n";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label23);
            this.groupBox5.Controls.Add(this.checkInvert);
            this.groupBox5.Controls.Add(this.lblBrightnessValue);
            this.groupBox5.Controls.Add(this.trackBrightness);
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Controls.Add(this.lblContrastValue);
            this.groupBox5.Controls.Add(this.trackContrast);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.checkEnableEffects);
            this.groupBox5.Location = new System.Drawing.Point(1241, 20);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(360, 180);
            this.groupBox5.TabIndex = 10;
            this.groupBox5.TabStop = false;
            // 
            // checkInvert
            // 
            this.checkInvert.AutoSize = true;
            this.checkInvert.Enabled = false;
            this.checkInvert.Location = new System.Drawing.Point(10, 140);
            this.checkInvert.Name = "checkInvert";
            this.checkInvert.Size = new System.Drawing.Size(109, 20);
            this.checkInvert.TabIndex = 7;
            this.checkInvert.Text = "Invert Texture";
            this.checkInvert.UseVisualStyleBackColor = true;
            // 
            // lblBrightnessValue
            // 
            this.lblBrightnessValue.ForeColor = System.Drawing.Color.White;
            this.lblBrightnessValue.Location = new System.Drawing.Point(310, 97);
            this.lblBrightnessValue.Name = "lblBrightnessValue";
            this.lblBrightnessValue.Size = new System.Drawing.Size(40, 20);
            this.lblBrightnessValue.TabIndex = 6;
            this.lblBrightnessValue.Text = "0.0";
            // 
            // trackBrightness
            // 
            this.trackBrightness.AutoSize = false;
            this.trackBrightness.Enabled = false;
            this.trackBrightness.Location = new System.Drawing.Point(100, 90);
            this.trackBrightness.Minimum = -3;
            this.trackBrightness.Name = "trackBrightness";
            this.trackBrightness.Size = new System.Drawing.Size(200, 45);
            this.trackBrightness.TabIndex = 5;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(10, 95);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(73, 16);
            this.label16.TabIndex = 4;
            this.label16.Text = "Brightness:\n";
            // 
            // lblContrastValue
            // 
            this.lblContrastValue.ForeColor = System.Drawing.Color.White;
            this.lblContrastValue.Location = new System.Drawing.Point(310, 57);
            this.lblContrastValue.Name = "lblContrastValue";
            this.lblContrastValue.Size = new System.Drawing.Size(40, 20);
            this.lblContrastValue.TabIndex = 3;
            this.lblContrastValue.Text = "1.0";
            // 
            // trackContrast
            // 
            this.trackContrast.AutoSize = false;
            this.trackContrast.Enabled = false;
            this.trackContrast.Location = new System.Drawing.Point(100, 50);
            this.trackContrast.Maximum = 20;
            this.trackContrast.Minimum = 5;
            this.trackContrast.Name = "trackContrast";
            this.trackContrast.Size = new System.Drawing.Size(200, 45);
            this.trackContrast.TabIndex = 2;
            this.trackContrast.Value = 10;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(10, 55);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(59, 16);
            this.label15.TabIndex = 1;
            this.label15.Text = "Contrast:";
            // 
            // checkEnableEffects
            // 
            this.checkEnableEffects.AutoSize = true;
            this.checkEnableEffects.Location = new System.Drawing.Point(10, 25);
            this.checkEnableEffects.Name = "checkEnableEffects";
            this.checkEnableEffects.Size = new System.Drawing.Size(115, 20);
            this.checkEnableEffects.TabIndex = 0;
            this.checkEnableEffects.Text = "Enable Effects\n";
            this.checkEnableEffects.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Location = new System.Drawing.Point(1163, 642);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(0, 0);
            this.groupBox6.TabIndex = 11;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "groupBox6";
            // 
            // checkTileable
            // 
            this.checkTileable.AutoSize = true;
            this.checkTileable.Location = new System.Drawing.Point(1241, 547);
            this.checkTileable.Name = "checkTileable";
            this.checkTileable.Size = new System.Drawing.Size(79, 20);
            this.checkTileable.TabIndex = 12;
            this.checkTileable.Text = "Tileable";
            this.checkTileable.UseVisualStyleBackColor = true;
            // 
            // checkShow2x2
            // 
            this.checkShow2x2.AutoSize = true;
            this.checkShow2x2.Location = new System.Drawing.Point(1327, 547);
            this.checkShow2x2.Name = "checkShow2x2";
            this.checkShow2x2.Size = new System.Drawing.Size(172, 20);
            this.checkShow2x2.TabIndex = 13;
            this.checkShow2x2.Text = "Show 2x2 Tiling Preview";
            this.checkShow2x2.UseVisualStyleBackColor = true;
            // 
            // lblNormalStrength
            // 
            this.lblNormalStrength.AutoSize = true;
            this.lblNormalStrength.ForeColor = System.Drawing.Color.White;
            this.lblNormalStrength.Location = new System.Drawing.Point(1238, 224);
            this.lblNormalStrength.Name = "lblNormalStrength";
            this.lblNormalStrength.Size = new System.Drawing.Size(106, 16);
            this.lblNormalStrength.TabIndex = 14;
            this.lblNormalStrength.Text = "Normal Strength:";
            // 
            // lblNormalStrengthValue
            // 
            this.lblNormalStrengthValue.AutoSize = true;
            this.lblNormalStrengthValue.ForeColor = System.Drawing.Color.White;
            this.lblNormalStrengthValue.Location = new System.Drawing.Point(1564, 225);
            this.lblNormalStrengthValue.Name = "lblNormalStrengthValue";
            this.lblNormalStrengthValue.Size = new System.Drawing.Size(24, 16);
            this.lblNormalStrengthValue.TabIndex = 15;
            this.lblNormalStrengthValue.Text = "3.0";
            // 
            // trackNormalStrength
            // 
            this.trackNormalStrength.AutoSize = false;
            this.trackNormalStrength.Location = new System.Drawing.Point(1340, 223);
            this.trackNormalStrength.Maximum = 100;
            this.trackNormalStrength.Minimum = 10;
            this.trackNormalStrength.Name = "trackNormalStrength";
            this.trackNormalStrength.Size = new System.Drawing.Size(218, 40);
            this.trackNormalStrength.TabIndex = 16;
            this.trackNormalStrength.TickFrequency = 10;
            this.trackNormalStrength.Value = 30;
            // 
            // trackSpecSmooth
            // 
            this.trackSpecSmooth.AutoSize = false;
            this.trackSpecSmooth.Location = new System.Drawing.Point(1340, 269);
            this.trackSpecSmooth.Maximum = 100;
            this.trackSpecSmooth.Name = "trackSpecSmooth";
            this.trackSpecSmooth.Size = new System.Drawing.Size(218, 40);
            this.trackSpecSmooth.TabIndex = 19;
            this.trackSpecSmooth.TickFrequency = 10;
            this.trackSpecSmooth.Value = 70;
            // 
            // lblSpecSmoothValue
            // 
            this.lblSpecSmoothValue.AutoSize = true;
            this.lblSpecSmoothValue.ForeColor = System.Drawing.Color.White;
            this.lblSpecSmoothValue.Location = new System.Drawing.Point(1564, 271);
            this.lblSpecSmoothValue.Name = "lblSpecSmoothValue";
            this.lblSpecSmoothValue.Size = new System.Drawing.Size(31, 16);
            this.lblSpecSmoothValue.TabIndex = 18;
            this.lblSpecSmoothValue.Text = "0.70";
            // 
            // lblSpecSmooth
            // 
            this.lblSpecSmooth.AutoSize = true;
            this.lblSpecSmooth.ForeColor = System.Drawing.Color.White;
            this.lblSpecSmooth.Location = new System.Drawing.Point(1238, 270);
            this.lblSpecSmooth.Name = "lblSpecSmooth";
            this.lblSpecSmooth.Size = new System.Drawing.Size(142, 16);
            this.lblSpecSmooth.TabIndex = 17;
            this.lblSpecSmooth.Text = "Specular Smoothness:";
            // 
            // checkExportRoughness
            // 
            this.checkExportRoughness.AutoSize = true;
            this.checkExportRoughness.Location = new System.Drawing.Point(1241, 521);
            this.checkExportRoughness.Name = "checkExportRoughness";
            this.checkExportRoughness.Size = new System.Drawing.Size(169, 20);
            this.checkExportRoughness.TabIndex = 20;
            this.checkExportRoughness.Text = "Export Roughness Map";
            this.checkExportRoughness.UseVisualStyleBackColor = true;
            // 
            // checkExportMetallic
            // 
            this.checkExportMetallic.AutoSize = true;
            this.checkExportMetallic.Location = new System.Drawing.Point(1412, 521);
            this.checkExportMetallic.Name = "checkExportMetallic";
            this.checkExportMetallic.Size = new System.Drawing.Size(146, 20);
            this.checkExportMetallic.TabIndex = 21;
            this.checkExportMetallic.Text = "Export Metallic Map";
            this.checkExportMetallic.UseVisualStyleBackColor = true;
            // 
            // checkUseLayerSystem
            // 
            this.checkUseLayerSystem.AutoSize = true;
            this.checkUseLayerSystem.Location = new System.Drawing.Point(1254, 305);
            this.checkUseLayerSystem.Name = "checkUseLayerSystem";
            this.checkUseLayerSystem.Size = new System.Drawing.Size(139, 20);
            this.checkUseLayerSystem.TabIndex = 22;
            this.checkUseLayerSystem.Text = "Use Layer System";
            this.checkUseLayerSystem.UseVisualStyleBackColor = true;
            // 
            // btnAddAsLayer
            // 
            this.btnAddAsLayer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.btnAddAsLayer.ForeColor = System.Drawing.Color.White;
            this.btnAddAsLayer.Location = new System.Drawing.Point(1241, 331);
            this.btnAddAsLayer.Name = "btnAddAsLayer";
            this.btnAddAsLayer.Size = new System.Drawing.Size(169, 45);
            this.btnAddAsLayer.TabIndex = 23;
            this.btnAddAsLayer.Text = "Add as Layer";
            this.btnAddAsLayer.UseVisualStyleBackColor = false;
            // 
            // btnOpenLayerManager
            // 
            this.btnOpenLayerManager.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.btnOpenLayerManager.ForeColor = System.Drawing.Color.White;
            this.btnOpenLayerManager.Location = new System.Drawing.Point(1241, 382);
            this.btnOpenLayerManager.Name = "btnOpenLayerManager";
            this.btnOpenLayerManager.Size = new System.Drawing.Size(169, 45);
            this.btnOpenLayerManager.TabIndex = 24;
            this.btnOpenLayerManager.Text = "Open Layer Manager";
            this.btnOpenLayerManager.UseVisualStyleBackColor = false;
            // 
            // btnSaveSession
            // 
            this.btnSaveSession.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.btnSaveSession.ForeColor = System.Drawing.Color.White;
            this.btnSaveSession.Location = new System.Drawing.Point(1495, 698);
            this.btnSaveSession.Name = "btnSaveSession";
            this.btnSaveSession.Size = new System.Drawing.Size(100, 60);
            this.btnSaveSession.TabIndex = 25;
            this.btnSaveSession.Text = "Save Session";
            this.btnSaveSession.UseVisualStyleBackColor = false;
            // 
            // btnLoadSession
            // 
            this.btnLoadSession.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.btnLoadSession.ForeColor = System.Drawing.Color.White;
            this.btnLoadSession.Location = new System.Drawing.Point(1241, 698);
            this.btnLoadSession.Name = "btnLoadSession";
            this.btnLoadSession.Size = new System.Drawing.Size(100, 60);
            this.btnLoadSession.TabIndex = 26;
            this.btnLoadSession.Text = "Load Session";
            this.btnLoadSession.UseVisualStyleBackColor = false;
            // 
            // checkAutoSave
            // 
            this.checkAutoSave.AutoSize = true;
            this.checkAutoSave.Location = new System.Drawing.Point(1350, 764);
            this.checkAutoSave.Name = "checkAutoSave";
            this.checkAutoSave.Size = new System.Drawing.Size(144, 20);
            this.checkAutoSave.TabIndex = 28;
            this.checkAutoSave.Text = "Auto-save on close";
            this.checkAutoSave.UseVisualStyleBackColor = true;
            // 
            // btnImportTexture
            // 
            this.btnImportTexture.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.btnImportTexture.ForeColor = System.Drawing.Color.White;
            this.btnImportTexture.Location = new System.Drawing.Point(1428, 331);
            this.btnImportTexture.Name = "btnImportTexture";
            this.btnImportTexture.Size = new System.Drawing.Size(170, 45);
            this.btnImportTexture.TabIndex = 29;
            this.btnImportTexture.Text = "Import Texture";
            this.btnImportTexture.UseVisualStyleBackColor = false;
            // 
            // btnApplyToImported
            // 
            this.btnApplyToImported.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.btnApplyToImported.ForeColor = System.Drawing.Color.White;
            this.btnApplyToImported.Location = new System.Drawing.Point(1428, 382);
            this.btnApplyToImported.Name = "btnApplyToImported";
            this.btnApplyToImported.Size = new System.Drawing.Size(170, 45);
            this.btnApplyToImported.TabIndex = 30;
            this.btnApplyToImported.Text = "Apply Effects to Imported";
            this.btnApplyToImported.UseVisualStyleBackColor = false;
            // 
            // btnMakeTileable
            // 
            this.btnMakeTileable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(75)))), ((int)(((byte)(75)))), ((int)(((byte)(75)))));
            this.btnMakeTileable.ForeColor = System.Drawing.Color.White;
            this.btnMakeTileable.Location = new System.Drawing.Point(1430, 433);
            this.btnMakeTileable.Name = "btnMakeTileable";
            this.btnMakeTileable.Size = new System.Drawing.Size(170, 45);
            this.btnMakeTileable.TabIndex = 31;
            this.btnMakeTileable.Text = "Make Tileable";
            this.btnMakeTileable.UseVisualStyleBackColor = false;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(10, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(160, 16);
            this.label18.TabIndex = 13;
            this.label18.Text = "Overlay Pattern (Optional)";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(10, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(90, 16);
            this.label20.TabIndex = 14;
            this.label20.Text = "Color Settings";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(10, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(100, 16);
            this.label21.TabIndex = 15;
            this.label21.Text = "Pattern Settings";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(8, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(94, 16);
            this.label22.TabIndex = 16;
            this.label22.Text = "Noise Settings\n";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(6, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(173, 16);
            this.label23.TabIndex = 17;
            this.label23.Text = "Advanced Effects (Optional)\n";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.BackgroundImage = global::Textural.Properties.Resources.texturaliconblacknwhite3;
            this.ClientSize = new System.Drawing.Size(1652, 981);
            this.Controls.Add(this.btnMakeTileable);
            this.Controls.Add(this.btnApplyToImported);
            this.Controls.Add(this.btnImportTexture);
            this.Controls.Add(this.checkAutoSave);
            this.Controls.Add(this.btnLoadSession);
            this.Controls.Add(this.btnSaveSession);
            this.Controls.Add(this.btnOpenLayerManager);
            this.Controls.Add(this.btnAddAsLayer);
            this.Controls.Add(this.checkUseLayerSystem);
            this.Controls.Add(this.checkExportMetallic);
            this.Controls.Add(this.checkExportRoughness);
            this.Controls.Add(this.trackSpecSmooth);
            this.Controls.Add(this.lblSpecSmoothValue);
            this.Controls.Add(this.lblSpecSmooth);
            this.Controls.Add(this.trackNormalStrength);
            this.Controls.Add(this.lblNormalStrengthValue);
            this.Controls.Add(this.lblNormalStrength);
            this.Controls.Add(this.checkShow2x2);
            this.Controls.Add(this.checkTileable);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.picturePreview);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnGenerate);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1600, 1018);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Textural";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackLacunarity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackPersistence)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackOctaves)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numScale)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numHeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numWidth)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackPatternParam)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackOverlayParam2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackOverlayParam1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackOverlayIntensity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picturePreview)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBrightness)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackContrast)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackNormalStrength)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackSpecSmooth)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numWidth;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboNoiseType;
        private System.Windows.Forms.NumericUpDown numHeight;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numScale;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TrackBar trackOctaves;
        private System.Windows.Forms.Label lblOctavesValue;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TrackBar trackPersistence;
        private System.Windows.Forms.Label lblPersistenceValue;
        private System.Windows.Forms.Label lblLacunarityValue;
        private System.Windows.Forms.TrackBar trackLacunarity;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboPattern;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TrackBar trackPatternParam;
        private System.Windows.Forms.Label lblPatternParamValue;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown numSeed;
        private System.Windows.Forms.Button btnRandomSeed;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox comboColor;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.CheckBox checkEnableOverlay;
        private System.Windows.Forms.TrackBar trackOverlayIntensity;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboOverlay;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.Label lblOverlayIntensityValue;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.PictureBox picturePreview;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.CheckBox checkEnableEffects;
        private System.Windows.Forms.Label lblContrastValue;
        private System.Windows.Forms.TrackBar trackContrast;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TrackBar trackBrightness;
        private System.Windows.Forms.Label lblBrightnessValue;
        private System.Windows.Forms.CheckBox checkInvert;
        private System.Windows.Forms.TrackBar trackOverlayParam1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblOverlayParam1Value;
        private System.Windows.Forms.Label lblOverlayParam2Value;
        private System.Windows.Forms.TrackBar trackOverlayParam2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblColor1;
        private System.Windows.Forms.Label lblColor2;
        private System.Windows.Forms.Button btnColor1;
        private System.Windows.Forms.Button btnColor3;
        private System.Windows.Forms.Label lblColor3;
        private System.Windows.Forms.Button btnColor2;
        private System.Windows.Forms.CheckBox checkTileable;
        private System.Windows.Forms.CheckBox checkShow2x2;
        private System.Windows.Forms.Label lblNormalStrength;
        private System.Windows.Forms.Label lblNormalStrengthValue;
        private System.Windows.Forms.TrackBar trackNormalStrength;
        private System.Windows.Forms.TrackBar trackSpecSmooth;
        private System.Windows.Forms.Label lblSpecSmoothValue;
        private System.Windows.Forms.Label lblSpecSmooth;
        private System.Windows.Forms.CheckBox checkExportRoughness;
        private System.Windows.Forms.CheckBox checkExportMetallic;
        private System.Windows.Forms.CheckBox checkUseLayerSystem;
        private System.Windows.Forms.Button btnAddAsLayer;
        private System.Windows.Forms.Button btnOpenLayerManager;
        private System.Windows.Forms.Button btnSaveSession;
        private System.Windows.Forms.Button btnLoadSession;
        private System.Windows.Forms.CheckBox checkAutoSave;
        private System.Windows.Forms.Button btnImportTexture;
        private System.Windows.Forms.Button btnApplyToImported;
        private System.Windows.Forms.Button btnMakeTileable;
        private System.Windows.Forms.CheckBox checkPlankUniqueGrain;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label23;
    }
}

