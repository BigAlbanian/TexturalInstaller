﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Linq;

namespace TextureGeneratorGUI
{
    public static class LocalTextureAnalyzer
    {
        // Main analysis entry point
        public static TextureAnalysisResult Analyze(Bitmap image)
        {
            // Resize to 256x256 for consistent analysis
            Bitmap sample = new Bitmap(image, new Size(256, 256));

            // Run all analysis passes
            float[] colorHistogram = ComputeColorHistogram(sample);
            float[] edgeData = ComputeEdgeStrength(sample);
            float[] frequencyData = ComputeFrequencyData(sample);
            Color[] dominantColors = ExtractDominantColors(sample, 3);
            float contrast = ComputeContrast(sample);
            float saturation = ComputeAverageSaturation(sample);
            float directionality = ComputeDirectionality(sample);
            float roughness = ComputeRoughness(sample);
            float periodicityScore = ComputePeriodicity(sample);

            sample.Dispose();

            // Classify pattern type
            string patternType = ClassifyPattern(
                colorHistogram, edgeData, frequencyData,
                contrast, saturation, directionality,
                roughness, periodicityScore
            );

            // Map to generator settings
            return BuildResult(
                patternType, dominantColors,
                contrast, saturation, directionality,
                roughness, periodicityScore, edgeData
            );
        }

        // ===========================
        // ANALYSIS PASSES
        // ===========================

        // Compute HSV histogram for color analysis
        private static float[] ComputeColorHistogram(Bitmap image)
        {
            float[] hueHistogram = new float[36]; // 10-degree buckets

            for (int y = 0; y < image.Height; y++)
            {
                for (int x = 0; x < image.Width; x++)
                {
                    Color pixel = image.GetPixel(x, y);
                    float h, s, v;
                    RGBToHSV(pixel, out h, out s, out v);

                    if (s > 0.1f) // Only count pixels with some saturation
                    {
                        int bucket = (int)(h / 10f) % 36;
                        hueHistogram[bucket]++;
                    }
                }
            }

            // Normalize
            float total = hueHistogram.Sum() + 1f;
            for (int i = 0; i < hueHistogram.Length; i++)
                hueHistogram[i] /= total;

            return hueHistogram;
        }

        // Sobel edge detection
        private static float[] ComputeEdgeStrength(Bitmap image)
        {
            float[] edges = new float[image.Width * image.Height];
            float totalEdge = 0f;
            float maxEdge = 0f;

            for (int y = 1; y < image.Height - 1; y++)
            {
                for (int x = 1; x < image.Width - 1; x++)
                {
                    float gx = GetGray(image, x - 1, y - 1) * -1 +
                               GetGray(image, x + 1, y - 1) * 1 +
                               GetGray(image, x - 1, y) * -2 +
                               GetGray(image, x + 1, y) * 2 +
                               GetGray(image, x - 1, y + 1) * -1 +
                               GetGray(image, x + 1, y + 1) * 1;

                    float gy = GetGray(image, x - 1, y - 1) * -1 +
                               GetGray(image, x, y - 1) * -2 +
                               GetGray(image, x + 1, y - 1) * -1 +
                               GetGray(image, x - 1, y + 1) * 1 +
                               GetGray(image, x, y + 1) * 2 +
                               GetGray(image, x + 1, y + 1) * 1;

                    float mag = (float)Math.Sqrt(gx * gx + gy * gy);
                    edges[y * image.Width + x] = mag;
                    totalEdge += mag;
                    maxEdge = Math.Max(maxEdge, mag);
                }
            }

            return edges;
        }

        // Simple frequency analysis using variance at different scales
        private static float[] ComputeFrequencyData(Bitmap image)
        {
            float[] freqs = new float[8]; // 8 frequency bands

            int[] scales = { 2, 4, 8, 16, 32, 64, 128, 256 };

            for (int s = 0; s < scales.Length; s++)
            {
                int scale = scales[s];
                float variance = 0f;
                int count = 0;

                for (int y = 0; y < image.Height - scale; y += scale)
                {
                    for (int x = 0; x < image.Width - scale; x += scale)
                    {
                        float v1 = GetGray(image, x, y);
                        float v2 = GetGray(image, x + scale, y);
                        variance += Math.Abs(v1 - v2);
                        count++;
                    }
                }

                freqs[s] = count > 0 ? variance / count : 0f;
            }

            return freqs;
        }

        // K-means color clustering to find dominant colors
        private static Color[] ExtractDominantColors(Bitmap image, int numColors)
        {
            // Sample pixels
            List<float[]> pixels = new List<float[]>();
            int step = Math.Max(1, image.Width * image.Height / 2000);

            for (int i = 0; i < image.Width * image.Height; i += step)
            {
                int x = i % image.Width;
                int y = i / image.Width;
                Color c = image.GetPixel(x, y);
                pixels.Add(new float[] { c.R / 255f, c.G / 255f, c.B / 255f });
            }

            // Simple k-means
            Random rng = new Random(42);
            float[][] centroids = new float[numColors][];
            for (int i = 0; i < numColors; i++)
            {
                int idx = rng.Next(pixels.Count);
                centroids[i] = (float[])pixels[idx].Clone();
            }

            // Iterate k-means
            for (int iter = 0; iter < 20; iter++)
            {
                float[][] sums = new float[numColors][];
                int[] counts = new int[numColors];
                for (int i = 0; i < numColors; i++)
                    sums[i] = new float[3];

                foreach (var pixel in pixels)
                {
                    int nearest = 0;
                    float minDist = float.MaxValue;
                    for (int k = 0; k < numColors; k++)
                    {
                        float dist = ColorDistance(pixel, centroids[k]);
                        if (dist < minDist)
                        {
                            minDist = dist;
                            nearest = k;
                        }
                    }

                    sums[nearest][0] += pixel[0];
                    sums[nearest][1] += pixel[1];
                    sums[nearest][2] += pixel[2];
                    counts[nearest]++;
                }

                for (int k = 0; k < numColors; k++)
                {
                    if (counts[k] > 0)
                    {
                        centroids[k][0] = sums[k][0] / counts[k];
                        centroids[k][1] = sums[k][1] / counts[k];
                        centroids[k][2] = sums[k][2] / counts[k];
                    }
                }
            }

            // Sort by brightness (dark to light)
            Array.Sort(centroids, (a, b) =>
                (a[0] + a[1] + a[2]).CompareTo(b[0] + b[1] + b[2]));

            // Convert back to Color
            return centroids.Select(c => Color.FromArgb(
                (int)(c[0] * 255),
                (int)(c[1] * 255),
                (int)(c[2] * 255)
            )).ToArray();
        }

        private static float ComputeContrast(Bitmap image)
        {
            float min = 1f, max = 0f;
            for (int y = 0; y < image.Height; y++)
                for (int x = 0; x < image.Width; x++)
                {
                    float g = GetGray(image, x, y);
                    min = Math.Min(min, g);
                    max = Math.Max(max, g);
                }
            return max - min;
        }

        private static float ComputeAverageSaturation(Bitmap image)
        {
            float total = 0f;
            for (int y = 0; y < image.Height; y++)
                for (int x = 0; x < image.Width; x++)
                {
                    float h, s, v;
                    RGBToHSV(image.GetPixel(x, y), out h, out s, out v);
                    total += s;
                }
            return total / (image.Width * image.Height);
        }

        // Measures horizontal vs vertical edge strength (for grain direction)
        private static float ComputeDirectionality(Bitmap image)
        {
            float horizontal = 0f;
            float vertical = 0f;

            for (int y = 1; y < image.Height - 1; y++)
            {
                for (int x = 1; x < image.Width - 1; x++)
                {
                    float gx = Math.Abs(GetGray(image, x + 1, y) - GetGray(image, x - 1, y));
                    float gy = Math.Abs(GetGray(image, x, y + 1) - GetGray(image, x, y - 1));
                    horizontal += gy; // Horizontal edges = vertical gradient
                    vertical += gx;
                }
            }

            // Returns -1 (horizontal) to 1 (vertical) directionality
            float total = horizontal + vertical + 0.001f;
            return (vertical - horizontal) / total;
        }

        // Measures surface roughness from local variance
        private static float ComputeRoughness(Bitmap image)
        {
            float totalVariance = 0f;
            int count = 0;
            int windowSize = 5;

            for (int y = windowSize; y < image.Height - windowSize; y += 2)
            {
                for (int x = windowSize; x < image.Width - windowSize; x += 2)
                {
                    float mean = 0f;
                    for (int dy = -windowSize; dy <= windowSize; dy++)
                        for (int dx = -windowSize; dx <= windowSize; dx++)
                            mean += GetGray(image, x + dx, y + dy);

                    mean /= (windowSize * 2 + 1) * (windowSize * 2 + 1);

                    float variance = 0f;
                    for (int dy = -windowSize; dy <= windowSize; dy++)
                        for (int dx = -windowSize; dx <= windowSize; dx++)
                        {
                            float diff = GetGray(image, x + dx, y + dy) - mean;
                            variance += diff * diff;
                        }

                    totalVariance += variance / ((windowSize * 2 + 1) * (windowSize * 2 + 1));
                    count++;
                }
            }

            return count > 0 ? totalVariance / count : 0f;
        }

        // Measures how much the texture repeats (for tileable detection)
        private static float ComputePeriodicity(Bitmap image)
        {
            // Compare left/right halves and top/bottom halves
            float hScore = 0f;
            float vScore = 0f;
            int samples = 100;
            Random rng = new Random(42);

            for (int i = 0; i < samples; i++)
            {
                int x = rng.Next(image.Width / 2);
                int y = rng.Next(image.Height);
                float g1 = GetGray(image, x, y);
                float g2 = GetGray(image, x + image.Width / 2, y);
                hScore += 1f - Math.Abs(g1 - g2);
            }

            for (int i = 0; i < samples; i++)
            {
                int x = rng.Next(image.Width);
                int y = rng.Next(image.Height / 2);
                float g1 = GetGray(image, x, y);
                float g2 = GetGray(image, x, y + image.Height / 2);
                vScore += 1f - Math.Abs(g1 - g2);
            }

            return ((hScore + vScore) / (samples * 2));
        }

        // ===========================
        // PATTERN CLASSIFICATION
        // ===========================
        private static string ClassifyPattern(
            float[] hueHist, float[] edges, float[] freqs,
            float contrast, float saturation, float directionality,
            float roughness, float periodicity)
        {
            // Score each pattern type
            Dictionary<string, float> scores = new Dictionary<string, float>
            {
                { "wood", 0f },
                { "marble", 0f },
                { "stone", 0f },
                { "metal", 0f },
                { "fabric", 0f },
                { "concrete", 0f },
                { "leather", 0f },
                { "ground", 0f },
                { "organic", 0f }
            };

            // Wood: warm brown hues, directional grain, medium contrast
            float warmHues = hueHist.Skip(0).Take(6).Sum() +  // 0-60 degrees (reds/yellows)
                            hueHist.Skip(0).Take(4).Sum();     // Extra weight on reds
            scores["wood"] += warmHues * 3.0f;
            scores["wood"] += Math.Abs(directionality) * 2.0f; // Strong directionality
            scores["wood"] += (saturation > 0.1f && saturation < 0.5f) ? 1.5f : 0f;
            scores["wood"] += (contrast > 0.2f && contrast < 0.7f) ? 1.0f : 0f;

            // Marble: high contrast, flowing veins, white/gray with color tints
            scores["marble"] += (contrast > 0.4f) ? 2.0f : 0f;
            scores["marble"] += freqs[0] * 2.0f; // High frequency detail
            scores["marble"] += (saturation < 0.2f) ? 1.5f : 0f; // Mostly desaturated
            scores["marble"] += periodicity * 1.5f;

            // Stone: medium roughness, low saturation, high frequency detail
            scores["stone"] += roughness * 3.0f;
            scores["stone"] += (saturation < 0.15f) ? 2.0f : 0f;
            scores["stone"] += freqs[1] * 1.5f;
            scores["stone"] += (contrast > 0.1f && contrast < 0.5f) ? 1.0f : 0f;

            // Metal: low saturation, high specular (low roughness), directional scratches
            scores["metal"] += (saturation < 0.1f) ? 2.5f : 0f;
            scores["metal"] += (roughness < 0.02f) ? 2.0f : 0f; // Smooth
            scores["metal"] += Math.Abs(directionality) * 1.5f;
            scores["metal"] += (contrast > 0.3f) ? 1.0f : 0f;

            // Fabric: regular repeating pattern, medium saturation, fine detail
            scores["fabric"] += periodicity * 3.0f;
            scores["fabric"] += freqs[2] * 2.0f;
            scores["fabric"] += (saturation > 0.1f) ? 1.0f : 0f;

            // Concrete: very low saturation, medium roughness, subtle variation
            float grayHues = hueHist.Skip(0).Take(36).Sum();
            scores["concrete"] += (saturation < 0.08f) ? 3.0f : 0f;
            scores["concrete"] += (roughness > 0.01f && roughness < 0.05f) ? 2.0f : 0f;
            scores["concrete"] += (contrast < 0.35f) ? 1.5f : 0f;

            // Leather: warm tones, bumpy surface, medium saturation
            scores["leather"] += warmHues * 1.5f;
            scores["leather"] += (roughness > 0.02f && roughness < 0.08f) ? 2.0f : 0f;
            scores["leather"] += (saturation > 0.15f && saturation < 0.4f) ? 1.5f : 0f;
            scores["leather"] += freqs[1] * 1.5f;

            // Ground: earthy colors, high roughness, irregular pattern
            scores["ground"] += warmHues * 1.0f;
            float greenHues = hueHist.Skip(10).Take(6).Sum(); // 100-160 degrees
            scores["ground"] += greenHues * 2.0f;
            scores["ground"] += (roughness > 0.04f) ? 2.0f : 0f;
            scores["ground"] += (saturation > 0.1f && saturation < 0.4f) ? 1.0f : 0f;

            // Organic: high color variety, medium roughness, irregular
            float colorVariety = hueHist.Count(h => h > 0.01f) / 36f;
            scores["organic"] += colorVariety * 3.0f;
            scores["organic"] += (roughness > 0.03f) ? 1.5f : 0f;

            // Return highest scoring pattern
            return scores.OrderByDescending(kv => kv.Value).First().Key;
        }

        // ===========================
        // BUILD FINAL RESULT
        // ===========================
        private static TextureAnalysisResult BuildResult(
            string patternType, Color[] dominantColors,
            float contrast, float saturation, float directionality,
            float roughness, float periodicity, float[] edgeData)
        {
            var result = new TextureAnalysisResult();
            result.PatternType = patternType;
            result.Confidence = ComputeConfidence(patternType, contrast, saturation, roughness);
            result.SuggestedTileable = periodicity > 0.7f;
            result.SuggestedColor1 = dominantColors[0];
            result.SuggestedColor2 = dominantColors[1 % dominantColors.Length];
            result.SuggestedColor3 = dominantColors[2 % dominantColors.Length];
            result.SuggestedColorMode = 8;

            // Normal strength from roughness
            result.SuggestedNormalStrength = 1.0f + roughness * 100f;
            result.SuggestedNormalStrength = Math.Max(1.0f, Math.Min(10.0f, result.SuggestedNormalStrength));

            // Specular from roughness (inverse)
            result.SuggestedSpecularSmoothness = Math.Max(0.0f, Math.Min(1.0f, 1.0f - roughness * 20f));

            // Pattern-specific settings
            switch (patternType)
            {
                case "wood":
                    result.SuggestedNoiseType = 2; // FBM
                    result.SuggestedPatternType = 10; // Wood Grain
                    result.SuggestedScale = 80f + (1f - Math.Abs(directionality)) * 40f;
                    result.SuggestedOctaves = 5;
                    result.SuggestedPersistence = 0.6f;
                    result.SuggestedLacunarity = 2.0f;
                    result.SuggestedPatternParam = 40f;
                    result.Description = "Wood grain texture with directional fiber pattern";
                    break;

                case "marble":
                    result.SuggestedNoiseType = 2;
                    result.SuggestedPatternType = 3; // Marble
                    result.SuggestedScale = 120f;
                    result.SuggestedOctaves = 6;
                    result.SuggestedPersistence = 0.5f;
                    result.SuggestedLacunarity = 2.5f;
                    result.SuggestedPatternParam = 60f;
                    result.Description = "Marble texture with flowing vein patterns";
                    break;

                case "stone":
                    result.SuggestedNoiseType = 2;
                    result.SuggestedPatternType = 5; // Stone
                    result.SuggestedScale = 100f;
                    result.SuggestedOctaves = 6;
                    result.SuggestedPersistence = 0.55f;
                    result.SuggestedLacunarity = 2.2f;
                    result.SuggestedPatternParam = 2.5f;
                    result.Description = "Stone surface with rough irregular texture";
                    break;

                case "metal":
                    result.SuggestedNoiseType = 2;
                    result.SuggestedPatternType = 7; // Brushed Metal
                    result.SuggestedScale = 150f;
                    result.SuggestedOctaves = 4;
                    result.SuggestedPersistence = 0.4f;
                    result.SuggestedLacunarity = 2.0f;
                    result.SuggestedPatternParam = 80f;
                    result.SuggestedSpecularSmoothness = 0.8f;
                    result.SuggestedNormalStrength = 2.0f;
                    result.Description = "Metal surface with directional brushing or scratches";
                    break;

                case "fabric":
                    result.SuggestedNoiseType = 2;
                    result.SuggestedPatternType = 9; // Checkerboard as base
                    result.SuggestedScale = 60f;
                    result.SuggestedOctaves = 4;
                    result.SuggestedPersistence = 0.5f;
                    result.SuggestedLacunarity = 2.0f;
                    result.SuggestedPatternParam = 30f;
                    result.Description = "Woven fabric with regular repeating pattern";
                    break;

                case "concrete":
                    result.SuggestedNoiseType = 2;
                    result.SuggestedPatternType = 5; // Stone
                    result.SuggestedScale = 130f;
                    result.SuggestedOctaves = 5;
                    result.SuggestedPersistence = 0.45f;
                    result.SuggestedLacunarity = 2.3f;
                    result.SuggestedPatternParam = 2.0f;
                    result.SuggestedSpecularSmoothness = 0.2f;
                    result.Description = "Concrete surface with subtle aggregate texture";
                    break;

                case "leather":
                    result.SuggestedNoiseType = 2;
                    result.SuggestedPatternType = 12; // Leather
                    result.SuggestedScale = 70f;
                    result.SuggestedOctaves = 5;
                    result.SuggestedPersistence = 0.55f;
                    result.SuggestedLacunarity = 2.1f;
                    result.SuggestedPatternParam = 15f;
                    result.Description = "Leather surface with organic grain pattern";
                    break;

                case "ground":
                    result.SuggestedNoiseType = 2;
                    result.SuggestedPatternType = 6; // Voronoi
                    result.SuggestedScale = 100f;
                    result.SuggestedOctaves = 6;
                    result.SuggestedPersistence = 0.6f;
                    result.SuggestedLacunarity = 2.0f;
                    result.SuggestedPatternParam = 50f;
                    result.Description = "Ground/earth surface with organic cellular pattern";
                    break;

                default: // organic / other
                    result.SuggestedNoiseType = 2;
                    result.SuggestedPatternType = 6; // Voronoi
                    result.SuggestedScale = 100f;
                    result.SuggestedOctaves = 5;
                    result.SuggestedPersistence = 0.5f;
                    result.SuggestedLacunarity = 2.0f;
                    result.SuggestedPatternParam = 50f;
                    result.Description = "Organic or unclassified texture";
                    break;
            }

            return result;
        }

        private static float ComputeConfidence(string patternType, float contrast, float saturation, float roughness)
        {
            // Simple heuristic for how confident we are
            float confidence = 0.5f;

            switch (patternType)
            {
                case "metal":
                    confidence = saturation < 0.08f ? 0.85f : 0.55f;
                    break;
                case "marble":
                    confidence = contrast > 0.5f && saturation < 0.2f ? 0.80f : 0.60f;
                    break;
                case "wood":
                    confidence = saturation > 0.1f ? 0.75f : 0.55f;
                    break;
                case "concrete":
                    confidence = saturation < 0.06f ? 0.80f : 0.55f;
                    break;
                default:
                    confidence = 0.60f;
                    break;
            }

            return confidence;
        }

        // ===========================
        // HELPERS
        // ===========================
        private static float GetGray(Bitmap image, int x, int y)
        {
            x = Math.Max(0, Math.Min(image.Width - 1, x));
            y = Math.Max(0, Math.Min(image.Height - 1, y));
            Color c = image.GetPixel(x, y);
            return (c.R * 0.299f + c.G * 0.587f + c.B * 0.114f) / 255f;
        }

        private static void RGBToHSV(Color color, out float h, out float s, out float v)
        {
            float r = color.R / 255f;
            float g = color.G / 255f;
            float b = color.B / 255f;

            float max = Math.Max(r, Math.Max(g, b));
            float min = Math.Min(r, Math.Min(g, b));
            float delta = max - min;

            v = max;
            s = max == 0 ? 0 : delta / max;

            if (delta == 0)
            {
                h = 0;
            }
            else if (max == r)
            {
                h = 60f * (((g - b) / delta) % 6);
            }
            else if (max == g)
            {
                h = 60f * ((b - r) / delta + 2);
            }
            else
            {
                h = 60f * ((r - g) / delta + 4);
            }

            if (h < 0) h += 360f;
        }

        private static float ColorDistance(float[] a, float[] b)
        {
            float dr = a[0] - b[0];
            float dg = a[1] - b[1];
            float db = a[2] - b[2];
            return dr * dr + dg * dg + db * db;
        }
    }
}