﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using Textural;

namespace TextureGeneratorGUI
{
    public class TextureAnalysisResult
    {
        public string PatternType { get; set; }
        public float Confidence { get; set; }
        public string Description { get; set; }
        public int SuggestedNoiseType { get; set; }
        public float SuggestedScale { get; set; }
        public int SuggestedOctaves { get; set; }
        public float SuggestedPersistence { get; set; }
        public float SuggestedLacunarity { get; set; }
        public int SuggestedPatternType { get; set; }
        public float SuggestedPatternParam { get; set; }
        public int SuggestedColorMode { get; set; }
        public Color SuggestedColor1 { get; set; }
        public Color SuggestedColor2 { get; set; }
        public Color SuggestedColor3 { get; set; }
        public bool SuggestedTileable { get; set; }
        public float SuggestedNormalStrength { get; set; }
        public float SuggestedSpecularSmoothness { get; set; }
    }

    public partial class PhotoToTextureWizard : Form
    {
        // Wizard state
        private int currentStep = 0;
        private const int TOTAL_STEPS = 4;

        // Data
        private Bitmap importedPhoto = null;
        private Bitmap processedPhoto = null;
        private TextureAnalysisResult analysisResult = null;

        public TextureAnalysisResult AnalysisResult => analysisResult;
        public Bitmap ProcessedTexture => processedPhoto;

        // Navigation controls
        private Button btnNext;
        private Button btnBack;
        private Button btnCancel;
        private Label lblStepTitle;
        private Label lblStepDescription;
        private Label lblStepIndicator;
        private ProgressBar progressWizard;
        private Panel panelContent;

        // Step panels
        private Panel panelStep1;
        private Panel panelStep2;
        private Panel panelStep3;
        private Panel panelStep4;

        // Step 1
        private PictureBox pictureImport;
        private Button btnSelectPhoto;
        private Label lblPhotoInfo;
        private CheckBox checkMakeTileable;
        private CheckBox checkRemoveLighting;
        private CheckBox checkNormalize;

        // Step 2
        private TextBox txtApiKey;
        private Label lblAnalysisStatus;
        private RadioButton radioParamMatch;
        private RadioButton radioDirectExtract;
        private RadioButton radioBothModes;

        // Step 3
        private Label lblPatternDetected;
        private Label lblConfidence;
        private Label lblDescription;
        private Panel pictureColor1;
        private Panel pictureColor2;
        private Panel pictureColor3;
        private Label lblSuggestedSettings;

        // Step 4
        private PictureBox pictureDiffResult;
        private PictureBox pictureNormalResult;
        private PictureBox pictureSpecResult;
        private Label lblResultsInfo;
        private ProgressBar progressGeneration;
        private Button btnSaveResults;

        public PhotoToTextureWizard()
        {
            BuildUI();
            ShowStep(0);
        }

        private void BuildUI()
        {
            this.Text = "Textural - Photo to Texture Wizard";
            this.Size = new Size(900, 750);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.BackColor = Color.FromArgb(40, 40, 45);
            this.ForeColor = Color.White;

            // === HEADER ===
            Panel panelHeader = new Panel();
            panelHeader.Dock = DockStyle.Top;
            panelHeader.Height = 80;
            panelHeader.BackColor = Color.FromArgb(30, 30, 35);
            this.Controls.Add(panelHeader);

            lblStepTitle = new Label();
            lblStepTitle.Font = new Font("Arial", 16, FontStyle.Bold);
            lblStepTitle.ForeColor = Color.White;
            lblStepTitle.Location = new Point(20, 10);
            lblStepTitle.Size = new Size(600, 30);
            panelHeader.Controls.Add(lblStepTitle);

            lblStepDescription = new Label();
            lblStepDescription.Font = new Font("Arial", 10);
            lblStepDescription.ForeColor = Color.LightGray;
            lblStepDescription.Location = new Point(20, 42);
            lblStepDescription.Size = new Size(600, 25);
            panelHeader.Controls.Add(lblStepDescription);

            lblStepIndicator = new Label();
            lblStepIndicator.Font = new Font("Arial", 10, FontStyle.Bold);
            lblStepIndicator.ForeColor = Color.LightBlue;
            lblStepIndicator.Location = new Point(780, 28);
            lblStepIndicator.Size = new Size(100, 25);
            lblStepIndicator.TextAlign = ContentAlignment.MiddleRight;
            panelHeader.Controls.Add(lblStepIndicator);

            // === PROGRESS BAR ===
            progressWizard = new ProgressBar();
            progressWizard.Dock = DockStyle.Top;
            progressWizard.Height = 6;
            progressWizard.Minimum = 0;
            progressWizard.Maximum = TOTAL_STEPS;
            progressWizard.Value = 0;
            this.Controls.Add(progressWizard);

            // === CONTENT PANEL ===
            panelContent = new Panel();
            panelContent.Dock = DockStyle.Fill;
            panelContent.BackColor = Color.FromArgb(40, 40, 45);
            this.Controls.Add(panelContent);

            // === FOOTER ===
            Panel panelFooter = new Panel();
            panelFooter.Dock = DockStyle.Bottom;
            panelFooter.Height = 55;
            panelFooter.BackColor = Color.FromArgb(30, 30, 35);
            this.Controls.Add(panelFooter);

            btnCancel = new Button();
            btnCancel.Text = "Cancel";
            btnCancel.Location = new Point(20, 12);
            btnCancel.Size = new Size(100, 32);
            btnCancel.BackColor = Color.FromArgb(80, 80, 85);
            btnCancel.ForeColor = Color.White;
            btnCancel.FlatStyle = FlatStyle.Flat;
            btnCancel.Click += (s, e) => this.DialogResult = DialogResult.Cancel;
            panelFooter.Controls.Add(btnCancel);

            btnBack = new Button();
            btnBack.Text = "← Back";
            btnBack.Location = new Point(660, 12);
            btnBack.Size = new Size(100, 32);
            btnBack.BackColor = Color.FromArgb(80, 80, 85);
            btnBack.ForeColor = Color.White;
            btnBack.FlatStyle = FlatStyle.Flat;
            btnBack.Click += BtnBack_Click;
            panelFooter.Controls.Add(btnBack);

            btnNext = new Button();
            btnNext.Text = "Next →";
            btnNext.Location = new Point(770, 12);
            btnNext.Size = new Size(110, 32);
            btnNext.BackColor = Color.FromArgb(0, 120, 215);
            btnNext.ForeColor = Color.White;
            btnNext.FlatStyle = FlatStyle.Flat;
            btnNext.Click += BtnNext_Click;
            panelFooter.Controls.Add(btnNext);

            // Build all step panels
            BuildStep1();
            BuildStep2();
            BuildStep3();
            BuildStep4();

            // Add panels to content
            panelContent.Controls.Add(panelStep1);
            panelContent.Controls.Add(panelStep2);
            panelContent.Controls.Add(panelStep3);
            panelContent.Controls.Add(panelStep4);
        }

        private Label MakeLabel(string text, int x, int y, int w = 200, int h = 25, float fontSize = 10)
        {
            var lbl = new Label();
            lbl.Text = text;
            lbl.Location = new Point(x, y);
            lbl.Size = new Size(w, h);
            lbl.ForeColor = Color.White;
            lbl.Font = new Font("Arial", fontSize);
            return lbl;
        }

        // ===========================
        // BUILD STEP PANELS
        // ===========================
        private void BuildStep1()
        {
            panelStep1 = new Panel();
            panelStep1.Dock = DockStyle.Fill;
            panelStep1.BackColor = Color.Transparent;

            panelStep1.Controls.Add(MakeLabel("Select a photo of a real surface (wood, stone, fabric, etc.)", 20, 15, 600, 25));

            pictureImport = new PictureBox();
            pictureImport.Location = new Point(20, 50);
            pictureImport.Size = new Size(450, 380);
            pictureImport.BackColor = Color.FromArgb(25, 25, 30);
            pictureImport.BorderStyle = BorderStyle.FixedSingle;
            pictureImport.SizeMode = PictureBoxSizeMode.Zoom;
            panelStep1.Controls.Add(pictureImport);

            btnSelectPhoto = new Button();
            btnSelectPhoto.Text = "📁 Select Photo";
            btnSelectPhoto.Location = new Point(20, 440);
            btnSelectPhoto.Size = new Size(150, 35);
            btnSelectPhoto.BackColor = Color.FromArgb(0, 120, 215);
            btnSelectPhoto.ForeColor = Color.White;
            btnSelectPhoto.FlatStyle = FlatStyle.Flat;
            btnSelectPhoto.Click += BtnSelectPhoto_Click;
            panelStep1.Controls.Add(btnSelectPhoto);

            lblPhotoInfo = new Label();
            lblPhotoInfo.Text = "No photo selected";
            lblPhotoInfo.Location = new Point(180, 445);
            lblPhotoInfo.Size = new Size(280, 40);
            lblPhotoInfo.ForeColor = Color.LightGray;
            panelStep1.Controls.Add(lblPhotoInfo);

            // Options panel
            Panel optPanel = new Panel();
            optPanel.Location = new Point(490, 50);
            optPanel.Size = new Size(370, 200);
            optPanel.BackColor = Color.FromArgb(30, 30, 35);
            panelStep1.Controls.Add(optPanel);

            optPanel.Controls.Add(MakeLabel("Processing Options", 10, 10, 300, 25, 12));

            checkMakeTileable = new CheckBox();
            checkMakeTileable.Text = "Make Tileable";
            checkMakeTileable.Location = new Point(10, 45);
            checkMakeTileable.Size = new Size(300, 25);
            checkMakeTileable.ForeColor = Color.White;
            checkMakeTileable.Checked = true;
            optPanel.Controls.Add(checkMakeTileable);

            checkRemoveLighting = new CheckBox();
            checkRemoveLighting.Text = "Remove Lighting (normalize brightness)";
            checkRemoveLighting.Location = new Point(10, 75);
            checkRemoveLighting.Size = new Size(300, 25);
            checkRemoveLighting.ForeColor = Color.White;
            checkRemoveLighting.Checked = true;
            optPanel.Controls.Add(checkRemoveLighting);

            checkNormalize = new CheckBox();
            checkNormalize.Text = "Normalize Colors";
            checkNormalize.Location = new Point(10, 105);
            checkNormalize.Size = new Size(300, 25);
            checkNormalize.ForeColor = Color.White;
            checkNormalize.Checked = true;
            optPanel.Controls.Add(checkNormalize);
        }

        private void BuildStep2()
        {
            panelStep2 = new Panel();
            panelStep2.Dock = DockStyle.Fill;
            panelStep2.BackColor = Color.Transparent;

            panelStep2.Controls.Add(MakeLabel("Local Texture Analysis", 20, 20, 400, 30, 14));
            panelStep2.Controls.Add(MakeLabel("No internet connection or API key required.", 20, 55, 500, 25, 10));

            // Info panel
            Panel infoPanel = new Panel();
            infoPanel.Location = new Point(20, 90);
            infoPanel.Size = new Size(840, 220);
            infoPanel.BackColor = Color.FromArgb(30, 30, 35);
            panelStep2.Controls.Add(infoPanel);

            infoPanel.Controls.Add(MakeLabel("How Local Analysis Works:", 15, 12, 400, 25, 12));

            string[] steps = {
                "1. Color histogram analysis - extracts dominant colors and saturation",
                "2. Edge detection (Sobel) - measures surface roughness and detail",
                "3. Frequency analysis - determines texture scale and complexity",
                "4. Directionality detection - finds grain/fiber direction",
                "5. Pattern classification - identifies texture type (wood, stone, metal etc.)",
                "6. PBR map generation - creates normal, specular and roughness maps"
            };

            for (int i = 0; i < steps.Length; i++)
            {
                Label lbl = MakeLabel(steps[i], 15, 45 + i * 27, 800, 22, 10);
                lbl.ForeColor = Color.LightGray;
                infoPanel.Controls.Add(lbl);
            }

            // Mode selection
            Panel modePanel = new Panel();
            modePanel.Location = new Point(20, 325);
            modePanel.Size = new Size(840, 120);
            modePanel.BackColor = Color.FromArgb(30, 30, 35);
            panelStep2.Controls.Add(modePanel);

            modePanel.Controls.Add(MakeLabel("Analysis Mode:", 15, 12, 300, 25, 12));

            radioParamMatch = new RadioButton();
            radioParamMatch.Text = "Mode A: Parameter Matching only (configure generator sliders)";
            radioParamMatch.Location = new Point(15, 42);
            radioParamMatch.Size = new Size(790, 25);
            radioParamMatch.ForeColor = Color.White;
            modePanel.Controls.Add(radioParamMatch);

            radioDirectExtract = new RadioButton();
            radioDirectExtract.Text = "Mode B: Direct PBR Extraction only (photo → texture maps)";
            radioDirectExtract.Location = new Point(15, 72);
            radioDirectExtract.Size = new Size(790, 25);
            radioDirectExtract.ForeColor = Color.White;
            modePanel.Controls.Add(radioDirectExtract);

            radioBothModes = new RadioButton();
            radioBothModes.Text = "Both Modes (recommended)";
            radioBothModes.Location = new Point(15, 102);
            radioBothModes.Size = new Size(790, 25);
            radioBothModes.ForeColor = Color.White;
            radioBothModes.Checked = true;
            modePanel.Controls.Add(radioBothModes);

            lblAnalysisStatus = new Label();
            lblAnalysisStatus.Text = "";
            lblAnalysisStatus.Location = new Point(20, 460);
            lblAnalysisStatus.Size = new Size(600, 25);
            lblAnalysisStatus.ForeColor = Color.LightGreen;
            panelStep2.Controls.Add(lblAnalysisStatus);
        }

        private void BuildStep3()
        {
            panelStep3 = new Panel();
            panelStep3.Dock = DockStyle.Fill;
            panelStep3.BackColor = Color.Transparent;

            // Detection results panel
            Panel detectPanel = new Panel();
            detectPanel.Location = new Point(20, 15);
            detectPanel.Size = new Size(400, 200);
            detectPanel.BackColor = Color.FromArgb(30, 30, 35);
            panelStep3.Controls.Add(detectPanel);

            detectPanel.Controls.Add(MakeLabel("Detection Results", 15, 10, 300, 25, 12));

            lblPatternDetected = new Label();
            lblPatternDetected.Text = "Pattern: -";
            lblPatternDetected.Location = new Point(15, 45);
            lblPatternDetected.Size = new Size(370, 30);
            lblPatternDetected.ForeColor = Color.LightGreen;
            lblPatternDetected.Font = new Font("Arial", 14, FontStyle.Bold);
            detectPanel.Controls.Add(lblPatternDetected);

            lblConfidence = new Label();
            lblConfidence.Text = "Confidence: -";
            lblConfidence.Location = new Point(15, 80);
            lblConfidence.Size = new Size(370, 25);
            lblConfidence.ForeColor = Color.White;
            detectPanel.Controls.Add(lblConfidence);

            lblDescription = new Label();
            lblDescription.Text = "";
            lblDescription.Location = new Point(15, 110);
            lblDescription.Size = new Size(370, 80);
            lblDescription.ForeColor = Color.LightGray;
            lblDescription.Font = new Font("Arial", 9);
            detectPanel.Controls.Add(lblDescription);

            // Detected colors panel
            Panel colorPanel = new Panel();
            colorPanel.Location = new Point(430, 15);
            colorPanel.Size = new Size(430, 200);
            colorPanel.BackColor = Color.FromArgb(30, 30, 35);
            panelStep3.Controls.Add(colorPanel);

            colorPanel.Controls.Add(MakeLabel("Detected Color Palette", 15, 10, 300, 25, 12));

            pictureColor1 = new Panel();
            pictureColor1.Location = new Point(20, 50);
            pictureColor1.Size = new Size(80, 80);
            pictureColor1.BackColor = Color.Gray;
            pictureColor1.BorderStyle = BorderStyle.FixedSingle;
            colorPanel.Controls.Add(pictureColor1);
            colorPanel.Controls.Add(MakeLabel("Dark", 30, 135, 60, 20, 9));

            pictureColor2 = new Panel();
            pictureColor2.Location = new Point(170, 50);
            pictureColor2.Size = new Size(80, 80);
            pictureColor2.BackColor = Color.Gray;
            pictureColor2.BorderStyle = BorderStyle.FixedSingle;
            colorPanel.Controls.Add(pictureColor2);
            colorPanel.Controls.Add(MakeLabel("Mid", 182, 135, 60, 20, 9));

            pictureColor3 = new Panel();
            pictureColor3.Location = new Point(320, 50);
            pictureColor3.Size = new Size(80, 80);
            pictureColor3.BackColor = Color.Gray;
            pictureColor3.BorderStyle = BorderStyle.FixedSingle;
            colorPanel.Controls.Add(pictureColor3);
            colorPanel.Controls.Add(MakeLabel("Light", 330, 135, 60, 20, 9));

            // Suggested settings panel
            Panel settingsPanel = new Panel();
            settingsPanel.Location = new Point(20, 225);
            settingsPanel.Size = new Size(840, 200);
            settingsPanel.BackColor = Color.FromArgb(30, 30, 35);
            panelStep3.Controls.Add(settingsPanel);

            settingsPanel.Controls.Add(MakeLabel("Suggested Generator Settings", 15, 10, 400, 25, 12));

            lblSuggestedSettings = new Label();
            lblSuggestedSettings.Text = "Waiting for analysis...";
            lblSuggestedSettings.Location = new Point(15, 45);
            lblSuggestedSettings.Size = new Size(800, 140);
            lblSuggestedSettings.ForeColor = Color.LightGray;
            lblSuggestedSettings.Font = new Font("Consolas", 10);
            settingsPanel.Controls.Add(lblSuggestedSettings);
        }

        private void BuildStep4()
        {
            panelStep4 = new Panel();
            panelStep4.Dock = DockStyle.Fill;
            panelStep4.BackColor = Color.Transparent;

            panelStep4.Controls.Add(MakeLabel("Generated PBR Maps", 20, 10, 400, 30, 14));

            // Diffuse
            Panel diffPanel = new Panel();
            diffPanel.Location = new Point(20, 50);
            diffPanel.Size = new Size(250, 280);
            diffPanel.BackColor = Color.FromArgb(30, 30, 35);
            panelStep4.Controls.Add(diffPanel);
            diffPanel.Controls.Add(MakeLabel("Diffuse / Albedo", 10, 8, 230, 20, 10));
            pictureDiffResult = new PictureBox();
            pictureDiffResult.Location = new Point(10, 35);
            pictureDiffResult.Size = new Size(230, 230);
            pictureDiffResult.BackColor = Color.FromArgb(20, 20, 25);
            pictureDiffResult.SizeMode = PictureBoxSizeMode.Zoom;
            diffPanel.Controls.Add(pictureDiffResult);

            // Normal
            Panel normalPanel = new Panel();
            normalPanel.Location = new Point(285, 50);
            normalPanel.Size = new Size(250, 280);
            normalPanel.BackColor = Color.FromArgb(30, 30, 35);
            panelStep4.Controls.Add(normalPanel);
            normalPanel.Controls.Add(MakeLabel("Normal Map", 10, 8, 230, 20, 10));
            pictureNormalResult = new PictureBox();
            pictureNormalResult.Location = new Point(10, 35);
            pictureNormalResult.Size = new Size(230, 230);
            pictureNormalResult.BackColor = Color.FromArgb(20, 20, 25);
            pictureNormalResult.SizeMode = PictureBoxSizeMode.Zoom;
            normalPanel.Controls.Add(pictureNormalResult);

            // Specular
            Panel specPanel = new Panel();
            specPanel.Location = new Point(550, 50);
            specPanel.Size = new Size(250, 280);
            specPanel.BackColor = Color.FromArgb(30, 30, 35);
            panelStep4.Controls.Add(specPanel);
            specPanel.Controls.Add(MakeLabel("Specular / Roughness", 10, 8, 230, 20, 10));
            pictureSpecResult = new PictureBox();
            pictureSpecResult.Location = new Point(10, 35);
            pictureSpecResult.Size = new Size(230, 230);
            pictureSpecResult.BackColor = Color.FromArgb(20, 20, 25);
            pictureSpecResult.SizeMode = PictureBoxSizeMode.Zoom;
            specPanel.Controls.Add(pictureSpecResult);

            // Progress and status
            progressGeneration = new ProgressBar();
            progressGeneration.Location = new Point(20, 345);
            progressGeneration.Size = new Size(840, 20);
            progressGeneration.Minimum = 0;
            progressGeneration.Maximum = 100;
            panelStep4.Controls.Add(progressGeneration);

            lblResultsInfo = new Label();
            lblResultsInfo.Text = "Generating maps...";
            lblResultsInfo.Location = new Point(20, 373);
            lblResultsInfo.Size = new Size(600, 25);
            lblResultsInfo.ForeColor = Color.LightGreen;
            panelStep4.Controls.Add(lblResultsInfo);

            btnSaveResults = new Button();
            btnSaveResults.Text = "💾 Save All Maps";
            btnSaveResults.Location = new Point(680, 368);
            btnSaveResults.Size = new Size(160, 32);
            btnSaveResults.BackColor = Color.FromArgb(0, 150, 80);
            btnSaveResults.ForeColor = Color.White;
            btnSaveResults.FlatStyle = FlatStyle.Flat;
            btnSaveResults.Click += BtnSaveResults_Click;
            panelStep4.Controls.Add(btnSaveResults);
        }

        // ===========================
        // WIZARD NAVIGATION
        // ===========================
        private void ShowStep(int step)
        {
            currentStep = step;

            panelStep1.Visible = false;
            panelStep2.Visible = false;
            panelStep3.Visible = false;
            panelStep4.Visible = false;

            switch (step)
            {
                case 0:
                    panelStep1.Visible = true;
                    lblStepTitle.Text = "Step 1: Import Photo";
                    lblStepDescription.Text = "Select a photo of a real surface to convert into a texture.";
                    btnBack.Enabled = false;
                    btnNext.Enabled = importedPhoto != null;
                    btnNext.Text = "Next →";
                    break;
                case 1:
                    panelStep2.Visible = true;
                    lblStepTitle.Text = "Step 2: Configure Analysis";
                    lblStepDescription.Text = "Enter your Claude API key and select conversion mode.";
                    btnBack.Enabled = true;
                    btnNext.Enabled = true;
                    btnNext.Text = "Analyze →";
                    break;
                case 2:
                    panelStep3.Visible = true;
                    lblStepTitle.Text = "Step 3: Analysis Results";
                    lblStepDescription.Text = "Review what Claude detected and the suggested parameters.";
                    btnBack.Enabled = true;
                    btnNext.Enabled = analysisResult != null;
                    btnNext.Text = "Generate Maps →";
                    break;
                case 3:
                    panelStep4.Visible = true;
                    lblStepTitle.Text = "Step 4: Generated PBR Maps";
                    lblStepDescription.Text = "Your texture maps have been generated and are ready to use.";
                    btnBack.Enabled = true;
                    btnNext.Enabled = false;
                    btnNext.Text = "Apply & Finish ✓";
                    break;
            }

            progressWizard.Value = step;
            lblStepIndicator.Text = $"Step {step + 1} of {TOTAL_STEPS}";
        }

        private async void BtnNext_Click(object sender, EventArgs e)
        {
            switch (currentStep)
            {
                case 0:
                    ProcessPhoto();
                    ShowStep(1);
                    break;

                case 1:
                    btnNext.Enabled = false;
                    btnNext.Text = "Analyzing...";
                    lblAnalysisStatus.Text = "Analyzing texture locally...";

                    await RunAnalysis();

                    ShowStep(2);
                    break;

                case 2:
                    btnNext.Enabled = false;
                    btnNext.Text = "Generating...";
                    ShowStep(3);
                    await GeneratePBRMaps();
                    break;

                case 3:
                    this.DialogResult = DialogResult.OK;
                    break;
            }
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            if (currentStep > 0)
                ShowStep(currentStep - 1);
        }

        // ===========================
        // STEP 1: PHOTO IMPORT
        // ===========================
        private void BtnSelectPhoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files|*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff|All Files|*.*";
            ofd.Title = "Select Surface Photo";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    importedPhoto?.Dispose();
                    importedPhoto = new Bitmap(ofd.FileName);

                    pictureImport.Image?.Dispose();
                    pictureImport.Image = new Bitmap(importedPhoto);

                    lblPhotoInfo.Text = $"File: {Path.GetFileName(ofd.FileName)}\nSize: {importedPhoto.Width}x{importedPhoto.Height}px";
                    btnNext.Enabled = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Failed to load image: {ex.Message}", "Error");
                }
            }
        }

        private void ProcessPhoto()
        {
            if (importedPhoto == null) return;

            processedPhoto = new Bitmap(importedPhoto);

            if (checkNormalize.Checked)
                processedPhoto = TextureImporter.Normalize(processedPhoto);

            if (checkRemoveLighting.Checked)
                processedPhoto = RemoveLighting(processedPhoto);

            if (checkMakeTileable.Checked)
            {
                Bitmap tileable = TextureImporter.MakeTileable(processedPhoto);
                processedPhoto.Dispose();
                processedPhoto = tileable;
            }
        }

        private Bitmap RemoveLighting(Bitmap source)
        {
            Bitmap result = new Bitmap(source.Width, source.Height);

            float avgBrightness = 0;
            for (int y = 0; y < source.Height; y++)
                for (int x = 0; x < source.Width; x++)
                {
                    Color p = source.GetPixel(x, y);
                    avgBrightness += (p.R + p.G + p.B) / 3.0f / 255.0f;
                }
            avgBrightness /= source.Width * source.Height;

            float adjustment = 0.5f / Math.Max(0.01f, avgBrightness);

            for (int y = 0; y < source.Height; y++)
                for (int x = 0; x < source.Width; x++)
                {
                    Color p = source.GetPixel(x, y);
                    int r = Math.Max(0, Math.Min(255, (int)(p.R * adjustment)));
                    int g = Math.Max(0, Math.Min(255, (int)(p.G * adjustment)));
                    int b = Math.Max(0, Math.Min(255, (int)(p.B * adjustment)));
                    result.SetPixel(x, y, Color.FromArgb(r, g, b));
                }

            source.Dispose();
            return result;
        }

        // ===========================
        // STEP 2: LOCAL ANALYSIS
        // ===========================
        private async Task RunAnalysis()
        {
            try
            {
                await Task.Run(() =>
                {
                    analysisResult = LocalTextureAnalyzer.Analyze(processedPhoto);
                });

                this.Invoke((Action)(() => {
                    UpdateAnalysisUI();
                    lblAnalysisStatus.Text = "✓ Analysis complete!";
                }));
            }
            catch (Exception ex)
            {
                this.Invoke((Action)(() => {
                    lblAnalysisStatus.Text = $"Analysis failed: {ex.Message}";
                    MessageBox.Show($"Analysis error: {ex.Message}", "Error");
                    btnNext.Enabled = true;
                    btnNext.Text = "Analyze →";
                }));
            }
        }

        private void UpdateAnalysisUI()
        {
            if (analysisResult == null) return;

            lblPatternDetected.Text = $"Pattern: {analysisResult.PatternType.ToUpper()}";
            lblConfidence.Text = $"Confidence: {analysisResult.Confidence * 100:0}%";
            lblDescription.Text = analysisResult.Description;

            pictureColor1.BackColor = analysisResult.SuggestedColor1;
            pictureColor2.BackColor = analysisResult.SuggestedColor2;
            pictureColor3.BackColor = analysisResult.SuggestedColor3;

            lblSuggestedSettings.Text =
                $"Noise Type:         {(analysisResult.SuggestedNoiseType == 2 ? "FBM" : "Perlin")}    " +
                $"Scale: {analysisResult.SuggestedScale:0}    " +
                $"Octaves: {analysisResult.SuggestedOctaves}\n" +
                $"Persistence:        {analysisResult.SuggestedPersistence:0.0}    " +
                $"Lacunarity: {analysisResult.SuggestedLacunarity:0.0}\n" +
                $"Normal Strength:    {analysisResult.SuggestedNormalStrength:0.0}    " +
                $"Specular: {analysisResult.SuggestedSpecularSmoothness:0.00}\n" +
                $"Tileable:           {analysisResult.SuggestedTileable}    " +
                $"Pattern: {analysisResult.SuggestedPatternType}";

            btnNext.Enabled = true;
        }

        // ===========================
        // STEP 3: GENERATE PBR MAPS
        // ===========================
        private async Task GeneratePBRMaps()
        {
            try
            {
                await Task.Run(() =>
                {
                    void UpdateUI(int progress, string status) =>
                        this.Invoke((Action)(() => {
                            progressGeneration.Value = progress;
                            lblResultsInfo.Text = status;
                        }));

                    UpdateUI(10, "Saving diffuse map...");
                    string diffPath = Path.Combine(Path.GetTempPath(), "photo2tex_diff.png");
                    processedPhoto.Save(diffPath, ImageFormat.Png);

                    UpdateUI(30, "Generating heightmap...");
                    Bitmap heightmap = TextureImporter.ConvertToHeightmap(processedPhoto);

                    UpdateUI(50, "Generating normal map...");
                    float normalStrength = analysisResult?.SuggestedNormalStrength ?? 3.0f;
                    Bitmap normalMap = TextureImporter.GenerateNormalMapFromImage(heightmap, normalStrength);
                    string normalPath = Path.Combine(Path.GetTempPath(), "photo2tex_nmap.png");
                    normalMap.Save(normalPath, ImageFormat.Png);

                    UpdateUI(70, "Generating specular map...");
                    float specSmooth = analysisResult?.SuggestedSpecularSmoothness ?? 0.5f;
                    Bitmap specMap = GenerateSpecularMap(heightmap, specSmooth);
                    string specPath = Path.Combine(Path.GetTempPath(), "photo2tex_spec.png");
                    specMap.Save(specPath, ImageFormat.Png);

                    UpdateUI(85, "Generating roughness map...");
                    Bitmap roughMap = GenerateRoughnessMap(heightmap, specSmooth);
                    string roughPath = Path.Combine(Path.GetTempPath(), "photo2tex_rough.png");
                    roughMap.Save(roughPath, ImageFormat.Png);

                    UpdateUI(95, "Updating preview...");

                    this.Invoke((Action)(() => {
                        pictureDiffResult.Image?.Dispose();
                        pictureDiffResult.Image = new Bitmap(processedPhoto);

                        pictureNormalResult.Image?.Dispose();
                        pictureNormalResult.Image = new Bitmap(normalMap);

                        pictureSpecResult.Image?.Dispose();
                        pictureSpecResult.Image = new Bitmap(specMap);

                        progressGeneration.Value = 100;
                        lblResultsInfo.Text = "✓ All maps generated successfully!";
                        btnNext.Enabled = true;
                        btnNext.Text = "Apply & Finish ✓";
                    }));

                    heightmap.Dispose();
                    normalMap.Dispose();
                    specMap.Dispose();
                    roughMap.Dispose();
                });
            }
            catch (Exception ex)
            {
                this.Invoke((Action)(() => {
                    lblResultsInfo.Text = $"Error: {ex.Message}";
                    MessageBox.Show($"Generation error: {ex.Message}", "Error");
                    btnNext.Enabled = true;
                }));
            }
        }

        private Bitmap GenerateSpecularMap(Bitmap heightmap, float smoothness)
        {
            Bitmap specMap = new Bitmap(heightmap.Width, heightmap.Height);
            for (int y = 0; y < heightmap.Height; y++)
                for (int x = 0; x < heightmap.Width; x++)
                {
                    float h = heightmap.GetPixel(x, y).R / 255f;
                    float spec = (1.0f - h * 0.7f) * smoothness;
                    int val = (int)(Math.Max(0, Math.Min(1, spec)) * 255);
                    specMap.SetPixel(x, y, Color.FromArgb(val, val, val));
                }
            return specMap;
        }

        private Bitmap GenerateRoughnessMap(Bitmap heightmap, float smoothness)
        {
            Bitmap roughMap = new Bitmap(heightmap.Width, heightmap.Height);
            for (int y = 0; y < heightmap.Height; y++)
                for (int x = 0; x < heightmap.Width; x++)
                {
                    float h = heightmap.GetPixel(x, y).R / 255f;
                    float rough = h * 0.7f + (1.0f - smoothness) * 0.3f;
                    int val = (int)(Math.Max(0, Math.Min(1, rough)) * 255);
                    roughMap.SetPixel(x, y, Color.FromArgb(val, val, val));
                }
            return roughMap;
        }

        // ===========================
        // STEP 4: SAVE RESULTS
        // ===========================
        private void BtnSaveResults_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "PNG Image|*.png";
            sfd.FileName = "photo_texture.png";
            sfd.Title = "Save Photo Texture Set";
            sfd.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string basePath = sfd.FileName.Replace(".png", "");
                    string tempBase = Path.Combine(Path.GetTempPath(), "photo2tex");

                    File.Copy(tempBase + "_diff.png", basePath + "_diff.png", true);
                    File.Copy(tempBase + "_nmap.png", basePath + "_nmap.png", true);
                    File.Copy(tempBase + "_spec.png", basePath + "_spec.png", true);
                    File.Copy(tempBase + "_rough.png", basePath + "_rough.png", true);

                    MessageBox.Show(
                        $"Saved to:\n{Path.GetDirectoryName(basePath)}\n\n" +
                        $"• {Path.GetFileName(basePath)}_diff.png\n" +
                        $"• {Path.GetFileName(basePath)}_nmap.png\n" +
                        $"• {Path.GetFileName(basePath)}_spec.png\n" +
                        $"• {Path.GetFileName(basePath)}_rough.png",
                        "Saved Successfully!"
                    );
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Save error: {ex.Message}", "Error");
                }
            }
        }

        // ===========================
        // HELPERS
        // ===========================
        private Color HexToColor(string hex)
        {
            try
            {
                hex = hex.TrimStart('#');
                int r = Convert.ToInt32(hex.Substring(0, 2), 16);
                int g = Convert.ToInt32(hex.Substring(2, 2), 16);
                int b = Convert.ToInt32(hex.Substring(4, 2), 16);
                return Color.FromArgb(r, g, b);
            }
            catch { return Color.Gray; }
        }
    }
}