﻿using System;
using System.IO;
using System.Windows.Forms;
using Microsoft.Web.WebView2.WinForms;
using System.Drawing;

namespace TextureGeneratorGUI
{
    public partial class Preview3DForm : Form
    {
        private WebView2 webView;
        private string diffusePath;
        private string normalPath;
        private string specularPath;
        private ComboBox comboShape;
        private TrackBar trackLightX;
        private TrackBar trackLightY;
        private TrackBar trackLightZ;
        private Label lblLightX;
        private Label lblLightY;
        private Label lblLightZ;
        private Label lblLightColorPreview;
        private Button btnLightColor;
        private Button btnRefresh;
        private ComboBox comboEnvironment;
        private Panel panelControls;
        private Panel panelWebView;
        private Label label2;
        private Label label1;

        // Controls - add in designer:
        // ComboBox comboShape - items: Sphere, Plane, Cube
        // TrackBar trackLightX (Min:-100, Max:100, Value:50)
        // TrackBar trackLightY (Min:-100, Max:100, Value:100)
        // TrackBar trackLightZ (Min:-100, Max:100, Value:50)
        // Label lblLightX, lblLightY, lblLightZ
        // Button btnLightColor
        // Label lblLightColorPreview
        // ComboBox comboEnvironment - items: Studio, Sunset, Night, Outdoor
        // Button btnRefresh
        // Panel panelControls (right side panel for controls)
        // Panel panelWebView (left/main panel for 3D view)

        private Color lightColor = Color.White;

        public Preview3DForm(string diffuse, string normal, string specular)
        {
            InitializeComponent();

            diffusePath = diffuse;
            normalPath = normal;
            specularPath = specular;

            this.Text = "Textural - 3D Preview";
            this.Size = new Size(1200, 800);
            this.MinimumSize = new Size(800, 600);
            this.StartPosition = FormStartPosition.CenterScreen;

            InitializeWebView();
            InitializeControls();
        }

        private async void InitializeWebView()
        {
            webView = new WebView2();
            webView.Parent = panelWebView;
            webView.Dock = DockStyle.Fill;

            await webView.EnsureCoreWebView2Async(null);

            // Allow local file access
            webView.CoreWebView2.SetVirtualHostNameToFolderMapping(
                "textural.local",
                Path.GetTempPath(),
                Microsoft.Web.WebView2.Core.CoreWebView2HostResourceAccessKind.Allow
            );

            // Listen for messages from JavaScript
            webView.CoreWebView2.WebMessageReceived += WebView_WebMessageReceived;

            // Load the 3D viewer HTML
            string htmlPath = Path.Combine(Application.StartupPath, "viewer3d.html");
            if (!File.Exists(htmlPath))
            {
                GenerateViewerHTML(htmlPath);
            }

            webView.CoreWebView2.Navigate($"file:///{htmlPath}");
        }

        private void InitializeControls()
        {
            // Shape selector
            comboShape.Items.AddRange(new string[] { "Sphere", "Plane", "Cube" });
            comboShape.SelectedIndex = 0;
            comboShape.SelectedIndexChanged += (s, e) => UpdateShape();

            // Light sliders
            trackLightX.Scroll += (s, e) => UpdateLighting();
            trackLightY.Scroll += (s, e) => UpdateLighting();
            trackLightZ.Scroll += (s, e) => UpdateLighting();

            // Light color button
            btnLightColor.BackColor = lightColor;
            btnLightColor.Click += (s, e) =>
            {
                ColorDialog cd = new ColorDialog();
                cd.Color = lightColor;
                if (cd.ShowDialog() == DialogResult.OK)
                {
                    lightColor = cd.Color;
                    btnLightColor.BackColor = lightColor;
                    UpdateLighting();
                }
            };

            // Environment selector
            comboEnvironment.Items.AddRange(new string[] { "Studio", "Sunset", "Night", "Outdoor" });
            comboEnvironment.SelectedIndex = 0;
            comboEnvironment.SelectedIndexChanged += (s, e) => UpdateEnvironment();

            // Refresh button
            btnRefresh.Click += (s, e) => RefreshTextures();
        }

        private void WebView_WebMessageReceived(object sender, Microsoft.Web.WebView2.Core.CoreWebView2WebMessageReceivedEventArgs e)
        {
            // Handle messages from JavaScript if needed
            string message = e.TryGetWebMessageAsString();
            System.Diagnostics.Debug.WriteLine($"JS Message: {message}");
        }

        private void UpdateShape()
        {
            if (webView?.CoreWebView2 == null) return;
            string shape = comboShape.SelectedItem.ToString().ToLower();
            webView.CoreWebView2.PostWebMessageAsString($"shape:{shape}");
        }

        private void UpdateLighting()
        {
            if (webView?.CoreWebView2 == null) return;

            float x = trackLightX.Value / 10.0f;
            float y = trackLightY.Value / 10.0f;
            float z = trackLightZ.Value / 10.0f;
            float r = lightColor.R / 255.0f;
            float g = lightColor.G / 255.0f;
            float b = lightColor.B / 255.0f;

            webView.CoreWebView2.PostWebMessageAsString(
                $"light:{x},{y},{z},{r},{g},{b}"
            );
        }

        private void UpdateEnvironment()
        {
            if (webView?.CoreWebView2 == null) return;
            string env = comboEnvironment.SelectedItem.ToString().ToLower();
            webView.CoreWebView2.PostWebMessageAsString($"environment:{env}");
        }

        private void RefreshTextures()
        {
            if (webView?.CoreWebView2 == null) return;

            // Convert textures to base64 for passing to JavaScript
            string diffuseB64 = ImageToBase64(diffusePath);
            string normalB64 = ImageToBase64(normalPath);
            string specB64 = ImageToBase64(specularPath);

            webView.CoreWebView2.PostWebMessageAsString(
                $"textures:{diffuseB64}|{normalB64}|{specB64}"
            );
        }

        private string ImageToBase64(string imagePath)
        {
            if (!File.Exists(imagePath)) return "";
            byte[] bytes = File.ReadAllBytes(imagePath);
            return Convert.ToBase64String(bytes);
        }

        // Generate the Three.js HTML file
        private void GenerateViewerHTML(string outputPath)
        {
            string html = @"<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <title>Textural 3D Preview</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: #1a1a2e; overflow: hidden; }
        canvas { display: block; }
        #info {
            position: absolute;
            top: 10px;
            left: 10px;
            color: #aaa;
            font-family: Arial, sans-serif;
            font-size: 12px;
            pointer-events: none;
        }
    </style>
</head>
<body>
    <div id='info'>Left click + drag to rotate | Right click + drag to pan | Scroll to zoom</div>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js'></script>
    <script>
        // Scene setup
        const scene = new THREE.Scene();
        scene.background = new THREE.Color(0x1a1a2e);

        const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.position.set(0, 0, 3);

        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(window.devicePixelRatio);
        renderer.shadowMap.enabled = true;
        renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.0;
        document.body.appendChild(renderer.domElement);

        // Lighting
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.3);
        scene.add(ambientLight);

        const dirLight = new THREE.DirectionalLight(0xffffff, 1.0);
        dirLight.position.set(5, 10, 5);
        dirLight.castShadow = true;
        dirLight.shadow.mapSize.width = 2048;
        dirLight.shadow.mapSize.height = 2048;
        scene.add(dirLight);

        // Material
        const material = new THREE.MeshStandardMaterial({
            color: 0xffffff,
            roughness: 0.7,
            metalness: 0.1
        });

        // Default mesh (sphere)
        let currentMesh = null;

        function createMesh(shape) {
            if (currentMesh) {
                scene.remove(currentMesh);
                currentMesh.geometry.dispose();
            }

            let geometry;
            switch(shape) {
                case 'sphere':
                    geometry = new THREE.SphereGeometry(1, 64, 64);
                    break;
                case 'plane':
                    geometry = new THREE.PlaneGeometry(2, 2, 64, 64);
                    break;
                case 'cube':
                    geometry = new THREE.BoxGeometry(1.5, 1.5, 1.5, 16, 16, 16);
                    break;
                default:
                    geometry = new THREE.SphereGeometry(1, 64, 64);
            }

            currentMesh = new THREE.Mesh(geometry, material);
            currentMesh.castShadow = true;
            currentMesh.receiveShadow = true;
            scene.add(currentMesh);
        }

        createMesh('sphere');

        // Environment backgrounds
        function setEnvironment(env) {
            switch(env) {
                case 'studio':
                    scene.background = new THREE.Color(0x2a2a2a);
                    ambientLight.intensity = 0.5;
                    renderer.toneMappingExposure = 1.0;
                    break;
                case 'sunset':
                    scene.background = new THREE.Color(0xff6b35);
                    ambientLight.color.set(0xff8c69);
                    ambientLight.intensity = 0.6;
                    renderer.toneMappingExposure = 1.2;
                    break;
                case 'night':
                    scene.background = new THREE.Color(0x0a0a1a);
                    ambientLight.color.set(0x1a1a4a);
                    ambientLight.intensity = 0.2;
                    renderer.toneMappingExposure = 0.8;
                    break;
                case 'outdoor':
                    scene.background = new THREE.Color(0x87ceeb);
                    ambientLight.color.set(0xffffff);
                    ambientLight.intensity = 0.8;
                    renderer.toneMappingExposure = 1.3;
                    break;
            }
        }

        // Texture loading
        function loadTextures(diffuseB64, normalB64, specB64) {
            const loader = new THREE.TextureLoader();

            if (diffuseB64) {
                loader.load('data:image/png;base64,' + diffuseB64, function(tex) {
                    tex.wrapS = THREE.RepeatWrapping;
                    tex.wrapT = THREE.RepeatWrapping;
                    material.map = tex;
                    material.needsUpdate = true;
                });
            }

            if (normalB64) {
                loader.load('data:image/png;base64,' + normalB64, function(tex) {
                    tex.wrapS = THREE.RepeatWrapping;
                    tex.wrapT = THREE.RepeatWrapping;
                    material.normalMap = tex;
                    material.needsUpdate = true;
                });
            }

            if (specB64) {
                loader.load('data:image/png;base64,' + specB64, function(tex) {
                    tex.wrapS = THREE.RepeatWrapping;
                    tex.wrapT = THREE.RepeatWrapping;
                    material.roughnessMap = tex;
                    material.needsUpdate = true;
                });
            }
        }

        // Mouse controls (orbit)
        let isDragging = false;
        let isRightDragging = false;
        let prevMouse = { x: 0, y: 0 };
        let spherical = { theta: 0, phi: Math.PI / 2, radius: 3 };
        let panOffset = new THREE.Vector3();

        document.addEventListener('mousedown', (e) => {
            if (e.button === 0) isDragging = true;
            if (e.button === 2) isRightDragging = true;
            prevMouse = { x: e.clientX, y: e.clientY };
        });

        document.addEventListener('mouseup', () => {
            isDragging = false;
            isRightDragging = false;
        });

        document.addEventListener('mousemove', (e) => {
            const dx = e.clientX - prevMouse.x;
            const dy = e.clientY - prevMouse.y;

            if (isDragging) {
                spherical.theta -= dx * 0.01;
                spherical.phi = Math.max(0.1, Math.min(Math.PI - 0.1, spherical.phi - dy * 0.01));
                updateCamera();
            }

            if (isRightDragging) {
                panOffset.x -= dx * 0.005;
                panOffset.y += dy * 0.005;
                updateCamera();
            }

            prevMouse = { x: e.clientX, y: e.clientY };
        });

        document.addEventListener('wheel', (e) => {
            spherical.radius = Math.max(1, Math.min(10, spherical.radius + e.deltaY * 0.005));
            updateCamera();
        });

        document.addEventListener('contextmenu', (e) => e.preventDefault());

        function updateCamera() {
            camera.position.x = spherical.radius * Math.sin(spherical.phi) * Math.sin(spherical.theta) + panOffset.x;
            camera.position.y = spherical.radius * Math.cos(spherical.phi) + panOffset.y;
            camera.position.z = spherical.radius * Math.sin(spherical.phi) * Math.cos(spherical.theta);
            camera.lookAt(panOffset);
        }

        // Handle messages from C#
        window.chrome.webview.addEventListener('message', (event) => {
            const msg = event.data;

            if (msg.startsWith('shape:')) {
                const shape = msg.split(':')[1];
                createMesh(shape);
            }
            else if (msg.startsWith('light:')) {
                const parts = msg.split(':')[1].split(',');
                dirLight.position.set(parseFloat(parts[0]), parseFloat(parts[1]), parseFloat(parts[2]));
                dirLight.color.setRGB(parseFloat(parts[3]), parseFloat(parts[4]), parseFloat(parts[5]));
            }
            else if (msg.startsWith('environment:')) {
                const env = msg.split(':')[1];
                setEnvironment(env);
            }
            else if (msg.startsWith('textures:')) {
                const parts = msg.split(':')[1].split('|');
                loadTextures(parts[0], parts[1], parts[2]);
            }
        });

        // Animation loop
        function animate() {
            requestAnimationFrame(animate);
            renderer.render(scene, camera);
        }

        // Handle resize
        window.addEventListener('resize', () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        });

        animate();
    </script>
</body>
</html>";

            File.WriteAllText(outputPath, html);
        }

        private void InitializeComponent()
        {
            this.comboShape = new System.Windows.Forms.ComboBox();
            this.trackLightX = new System.Windows.Forms.TrackBar();
            this.trackLightY = new System.Windows.Forms.TrackBar();
            this.trackLightZ = new System.Windows.Forms.TrackBar();
            this.lblLightX = new System.Windows.Forms.Label();
            this.lblLightY = new System.Windows.Forms.Label();
            this.lblLightZ = new System.Windows.Forms.Label();
            this.lblLightColorPreview = new System.Windows.Forms.Label();
            this.btnLightColor = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.comboEnvironment = new System.Windows.Forms.ComboBox();
            this.panelControls = new System.Windows.Forms.Panel();
            this.panelWebView = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.trackLightX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackLightY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackLightZ)).BeginInit();
            this.panelControls.SuspendLayout();
            this.SuspendLayout();
            // 
            // comboShape
            // 
            this.comboShape.FormattingEnabled = true;
            this.comboShape.Location = new System.Drawing.Point(84, 12);
            this.comboShape.Name = "comboShape";
            this.comboShape.Size = new System.Drawing.Size(279, 24);
            this.comboShape.TabIndex = 0;
            // 
            // trackLightX
            // 
            this.trackLightX.Location = new System.Drawing.Point(84, 107);
            this.trackLightX.Maximum = 100;
            this.trackLightX.Minimum = -100;
            this.trackLightX.Name = "trackLightX";
            this.trackLightX.Size = new System.Drawing.Size(229, 56);
            this.trackLightX.TabIndex = 1;
            this.trackLightX.Value = 50;
            // 
            // trackLightY
            // 
            this.trackLightY.Location = new System.Drawing.Point(84, 169);
            this.trackLightY.Maximum = 100;
            this.trackLightY.Minimum = -100;
            this.trackLightY.Name = "trackLightY";
            this.trackLightY.Size = new System.Drawing.Size(229, 56);
            this.trackLightY.TabIndex = 2;
            this.trackLightY.Value = 50;
            // 
            // trackLightZ
            // 
            this.trackLightZ.Location = new System.Drawing.Point(84, 231);
            this.trackLightZ.Maximum = 100;
            this.trackLightZ.Minimum = -100;
            this.trackLightZ.Name = "trackLightZ";
            this.trackLightZ.Size = new System.Drawing.Size(229, 56);
            this.trackLightZ.TabIndex = 3;
            this.trackLightZ.Value = 50;
            // 
            // lblLightX
            // 
            this.lblLightX.AutoSize = true;
            this.lblLightX.Location = new System.Drawing.Point(319, 107);
            this.lblLightX.Name = "lblLightX";
            this.lblLightX.Size = new System.Drawing.Size(46, 16);
            this.lblLightX.TabIndex = 4;
            this.lblLightX.Text = "Light X";
            // 
            // lblLightY
            // 
            this.lblLightY.AutoSize = true;
            this.lblLightY.Location = new System.Drawing.Point(319, 169);
            this.lblLightY.Name = "lblLightY";
            this.lblLightY.Size = new System.Drawing.Size(47, 16);
            this.lblLightY.TabIndex = 5;
            this.lblLightY.Text = "Light Y";
            // 
            // lblLightZ
            // 
            this.lblLightZ.AutoSize = true;
            this.lblLightZ.Location = new System.Drawing.Point(319, 231);
            this.lblLightZ.Name = "lblLightZ";
            this.lblLightZ.Size = new System.Drawing.Size(46, 16);
            this.lblLightZ.TabIndex = 6;
            this.lblLightZ.Text = "Light Z";
            // 
            // lblLightColorPreview
            // 
            this.lblLightColorPreview.AutoSize = true;
            this.lblLightColorPreview.Location = new System.Drawing.Point(319, 313);
            this.lblLightColorPreview.Name = "lblLightColorPreview";
            this.lblLightColorPreview.Size = new System.Drawing.Size(70, 16);
            this.lblLightColorPreview.TabIndex = 7;
            this.lblLightColorPreview.Text = "Light Color";
            // 
            // btnLightColor
            // 
            this.btnLightColor.Location = new System.Drawing.Point(195, 313);
            this.btnLightColor.Name = "btnLightColor";
            this.btnLightColor.Size = new System.Drawing.Size(120, 50);
            this.btnLightColor.TabIndex = 8;
            this.btnLightColor.Text = "Pick Color";
            this.btnLightColor.UseVisualStyleBackColor = true;
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(195, 369);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(120, 50);
            this.btnRefresh.TabIndex = 9;
            this.btnRefresh.Text = "Refresh Textures";
            this.btnRefresh.UseVisualStyleBackColor = true;
            // 
            // comboEnvironment
            // 
            this.comboEnvironment.FormattingEnabled = true;
            this.comboEnvironment.Location = new System.Drawing.Point(84, 56);
            this.comboEnvironment.Name = "comboEnvironment";
            this.comboEnvironment.Size = new System.Drawing.Size(279, 24);
            this.comboEnvironment.TabIndex = 10;
            // 
            // panelControls
            // 
            this.panelControls.Controls.Add(this.label2);
            this.panelControls.Controls.Add(this.label1);
            this.panelControls.Controls.Add(this.comboShape);
            this.panelControls.Controls.Add(this.trackLightX);
            this.panelControls.Controls.Add(this.comboEnvironment);
            this.panelControls.Controls.Add(this.trackLightY);
            this.panelControls.Controls.Add(this.btnRefresh);
            this.panelControls.Controls.Add(this.trackLightZ);
            this.panelControls.Controls.Add(this.btnLightColor);
            this.panelControls.Controls.Add(this.lblLightX);
            this.panelControls.Controls.Add(this.lblLightColorPreview);
            this.panelControls.Controls.Add(this.lblLightY);
            this.panelControls.Controls.Add(this.lblLightZ);
            this.panelControls.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelControls.Location = new System.Drawing.Point(934, 0);
            this.panelControls.Name = "panelControls";
            this.panelControls.Size = new System.Drawing.Size(391, 753);
            this.panelControls.TabIndex = 11;
            // 
            // panelWebView
            // 
            this.panelWebView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelWebView.Location = new System.Drawing.Point(0, 0);
            this.panelWebView.Name = "panelWebView";
            this.panelWebView.Size = new System.Drawing.Size(934, 753);
            this.panelWebView.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 16);
            this.label1.TabIndex = 11;
            this.label1.Text = "Shape";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 16);
            this.label2.TabIndex = 12;
            this.label2.Text = "Environment";
            // 
            // Preview3DForm
            // 
            this.ClientSize = new System.Drawing.Size(1325, 753);
            this.Controls.Add(this.panelWebView);
            this.Controls.Add(this.panelControls);
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "Preview3DForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.trackLightX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackLightY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackLightZ)).EndInit();
            this.panelControls.ResumeLayout(false);
            this.panelControls.PerformLayout();
            this.ResumeLayout(false);

        }
    }
}